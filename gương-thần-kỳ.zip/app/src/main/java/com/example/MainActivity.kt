package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.RitualType
import com.example.ui.AppTab
import com.example.ui.AppViewModel
import com.example.ui.Screen
import com.example.ui.components.FestiveBottomBar
import com.example.ui.components.FestiveTopBar
import com.example.ui.screens.GameEggSmashScreen
import com.example.ui.screens.GameRedEnvelopeScreen
import com.example.ui.screens.GameTreasureChestScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.IncubatorScreen
import com.example.ui.screens.InventoryScreen
import com.example.ui.screens.LibrarySearchScreen
import com.example.ui.screens.RewardScreen
import com.example.ui.screens.RitualStep1Screen
import com.example.ui.screens.RitualStep2Screen
import com.example.ui.screens.RitualStep3Screen
import com.example.ui.screens.ZodiacPetScreen
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.MidnightSurfaceHigh
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.OnSurfaceText

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppContent(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MainAppContent(viewModel: AppViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val inventory by viewModel.userInventory.collectAsStateWithLifecycle()
    val savedBlessings by viewModel.savedBlessings.collectAsStateWithLifecycle()
    val activePet by viewModel.activeZodiacPet.collectAsStateWithLifecycle()
    val allPets by viewModel.allZodiacPets.collectAsStateWithLifecycle()

    val eggState by viewModel.eggGameState.collectAsStateWithLifecycle()
    val chestState by viewModel.chestGameState.collectAsStateWithLifecycle()
    val envelopeState by viewModel.envelopeGameState.collectAsStateWithLifecycle()

    val coins = inventory?.coins ?: 8888

    val isMainTab = uiState.currentScreen is Screen.TabView

    // Handle back button on sub-screens
    BackHandler(enabled = !isMainTab) {
        viewModel.goBack()
    }

    val topBarTitle = when (val scr = uiState.currentScreen) {
        is Screen.TabView -> when (scr.tab) {
            AppTab.HOME -> "Gương Thần Kỳ"
            AppTab.INCUBATOR -> "Ấp Trứng"
            AppTab.PETS -> "Linh Thú"
            AppTab.INVENTORY -> "Túi Đồ"
        }
        Screen.RitualStep1, Screen.RitualStep2, Screen.RitualStep3 -> "Chọn Quẻ May Mắn"
        Screen.GameEggSmash, Screen.GameTreasureChest, Screen.GameRedEnvelope -> "Minigame Hái Lộc Vàng"
        Screen.Reward -> "Nhận Thưởng Hoàng Kim"
        Screen.LibrarySearch -> "Kho 7.200 Câu Chúc"
    }

    val topBarSubtitle = when (val scr = uiState.currentScreen) {
        is Screen.TabView -> when (scr.tab) {
            AppTab.HOME -> "Ất Tỵ 2025"
            AppTab.INCUBATOR -> "Khí Vận Hoàng Kim"
            AppTab.PETS -> "Khí Vận Hoàng Kim"
            AppTab.INVENTORY -> "Khí Vận Hoàng Kim"
        }
        else -> null
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
            // Render TopBar for tabs and sub-screens (except Home where top status is built-in or custom)
            if (uiState.currentScreen != Screen.TabView(AppTab.HOME)) {
                FestiveTopBar(
                    title = topBarTitle,
                    subtitle = topBarSubtitle,
                    coins = coins,
                    showBackButton = !isMainTab,
                    onBackClick = { viewModel.goBack() }
                )
            }
        },
        bottomBar = {
            if (isMainTab) {
                FestiveBottomBar(
                    currentTab = uiState.activeTab,
                    onTabSelected = { viewModel.navigateToTab(it) }
                )
            }
        },
        containerColor = MidnightBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (val screen = uiState.currentScreen) {
                is Screen.TabView -> {
                    when (screen.tab) {
                        AppTab.HOME -> HomeScreen(
                            coins = coins,
                            onStartRitual = { viewModel.navigateToScreen(Screen.RitualStep1) },
                            onDailyGiftClick = {
                                viewModel.navigateToScreen(Screen.GameRedEnvelope)
                            },
                            onLibraryClick = {
                                viewModel.navigateToScreen(Screen.LibrarySearch)
                            },
                            onSettingsClick = {
                                viewModel.navigateToTab(AppTab.INVENTORY)
                            },
                            onMirrorTap = {
                                viewModel.showToast("Gương Thần Chiếu Mệnh: Khí vận ngút ngàn, vạn điều như ý!")
                            },
                            onPlayEggSmash = {
                                viewModel.setRitual(RitualType.EGG_SMASH)
                                viewModel.navigateToScreen(Screen.GameEggSmash)
                            },
                            onPlayTreasureChest = {
                                viewModel.setRitual(RitualType.TREASURE_CHEST)
                                viewModel.navigateToScreen(Screen.GameTreasureChest)
                            },
                            onPlayRedEnvelope = {
                                viewModel.setRitual(RitualType.RED_ENVELOPE)
                                viewModel.navigateToScreen(Screen.GameRedEnvelope)
                            }
                        )

                        AppTab.INCUBATOR -> IncubatorScreen(
                            secondsLeft = uiState.incubatorSeconds,
                            crackPercent = uiState.incubatorCrack,
                            onSpeedUp = { viewModel.speedUpIncubator() },
                            onWaterDrop = { viewModel.waterIncubatorNectar() },
                            onHammerAwaken = {
                                viewModel.hammerAwakenIncubator()
                                viewModel.setRitual(RitualType.EGG_SMASH)
                                viewModel.navigateToScreen(Screen.GameEggSmash)
                            }
                        )

                        AppTab.PETS -> ZodiacPetScreen(
                            activePet = activePet,
                            allPets = allPets,
                            onInteract = { viewModel.interactPet(it) },
                            onHarvest = { viewModel.harvestPetReward() }
                        )

                        AppTab.INVENTORY -> InventoryScreen(
                            inventory = inventory,
                            savedBlessings = savedBlessings,
                            onUseItem = { viewModel.quickUseItem(it) },
                            onSummonBlessing = { viewModel.navigateToScreen(Screen.RitualStep1) },
                            onQuickUse = { viewModel.quickUseItem("nectar") },
                            onOpenLibrary = { viewModel.navigateToScreen(Screen.LibrarySearch) },
                            onToast = { viewModel.showToast(it) }
                        )
                    }
                }

                Screen.RitualStep1 -> RitualStep1Screen(
                    selectedStyle = uiState.selectedStyle,
                    humorLevel = uiState.humorLevel,
                    onStyleChange = { viewModel.setStyle(it) },
                    onHumorLevelChange = { viewModel.setHumorLevel(it) },
                    onNextStep = { viewModel.navigateToScreen(Screen.RitualStep2) },
                    onGoHome = { viewModel.navigateToTab(AppTab.HOME) }
                )

                Screen.RitualStep2 -> RitualStep2Screen(
                    selectedTopic = uiState.selectedTopic,
                    onTopicSelected = { viewModel.setTopic(it) },
                    onNextStep = { viewModel.navigateToScreen(Screen.RitualStep3) }
                )

                Screen.RitualStep3 -> RitualStep3Screen(
                    onSelectRitual = { ritual ->
                        viewModel.setRitual(ritual)
                        when (ritual) {
                            RitualType.EGG_SMASH -> viewModel.navigateToScreen(Screen.GameEggSmash)
                            RitualType.TREASURE_CHEST -> viewModel.navigateToScreen(Screen.GameTreasureChest)
                            RitualType.RED_ENVELOPE -> viewModel.navigateToScreen(Screen.GameRedEnvelope)
                        }
                    }
                )

                Screen.GameEggSmash -> GameEggSmashScreen(
                    state = eggState,
                    coins = coins,
                    onStrike = { viewModel.gameController.strikeEgg() },
                    onSelectZodiac = { viewModel.gameController.selectEggZodiac(it) },
                    onReset = { viewModel.gameController.resetEggGame() },
                    onBack = { viewModel.goBack() }
                )

                Screen.GameTreasureChest -> GameTreasureChestScreen(
                    state = chestState,
                    coins = coins,
                    onTapNode = { viewModel.gameController.tapBaguaNode(it) },
                    onTouchChest = { viewModel.gameController.touchChestMirror() },
                    onOpenChest = { viewModel.gameController.openChest() },
                    onReset = { viewModel.gameController.resetChestGame() },
                    onBack = { viewModel.goBack() }
                )

                Screen.GameRedEnvelope -> GameRedEnvelopeScreen(
                    state = envelopeState,
                    dailyDrawsLeft = inventory?.dailyDrawsLeft ?: 5,
                    coins = coins,
                    onDrawEnvelope = { viewModel.gameController.selectEnvelopeByTouch(it) },
                    onTouchPouch = { viewModel.gameController.touchPouch() },
                    onShakeGesture = { viewModel.gameController.simulateShakeGesture() },
                    onAccelerometerReading = { viewModel.gameController.onAccelerometerReading(it) },
                    onReset = { viewModel.gameController.resetEnvelopeGame() },
                    onBack = { viewModel.goBack() }
                )

                Screen.Reward -> RewardScreen(
                    blessing = uiState.currentBlessing,
                    onClaimAndContinue = { viewModel.navigateToTab(AppTab.INVENTORY) },
                    onSaveToCollection = { viewModel.saveCurrentBlessing() }
                )

                Screen.LibrarySearch -> LibrarySearchScreen(
                    results = uiState.libraryResults,
                    isLoading = uiState.isLibraryLoading,
                    selectedTopic = uiState.libraryFilterTopic,
                    selectedStyle = uiState.libraryFilterStyle,
                    searchQuery = uiState.librarySearchQuery,
                    onSearchChange = { viewModel.searchLibrary(query = it) },
                    onFilterChange = { t, s -> viewModel.searchLibrary(topic = t, style = s) },
                    onSaveBlessing = {
                        viewModel.saveCurrentBlessing()
                        viewModel.showToast("Đã lưu lời chúc vào kho cá nhân!")
                    },
                    onBack = { viewModel.goBack() },
                    onToast = { viewModel.showToast(it) }
                )
            }

            // FLOATING TOAST NOTIFICATION
            AnimatedVisibility(
                visible = uiState.toastMessage != null,
                enter = fadeIn() + slideInVertically(initialOffsetY = { -40 }),
                exit = fadeOut() + slideOutVertically(targetOffsetY = { -40 }),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 70.dp, start = 16.dp, end = 16.dp)
            ) {
                uiState.toastMessage?.let { msg ->
                    Row(
                        modifier = Modifier
                            .shadow(16.dp, RoundedCornerShape(24.dp))
                            .clip(RoundedCornerShape(24.dp))
                            .background(MidnightSurfaceHigh.copy(alpha = 0.98f))
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = ImperialGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = msg,
                            color = OnSurfaceText,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
