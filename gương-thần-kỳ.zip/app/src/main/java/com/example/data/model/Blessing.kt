package com.example.data.model

data class Blessing(
    val id: String,
    val topic: String,
    val topicName: String,
    val style: String,
    val styleName: String,
    val title: String,
    val content: String,
    val rhyme: String,
    val omen: String,
    val code: String
)

enum class RitualType(val displayName: String, val iconName: String) {
    EGG_SMASH("Đập Trứng Vàng", "hardware"),
    TREASURE_CHEST("Gương Kho Báu", "auto_fix_high"),
    RED_ENVELOPE("Rút Bao Lì Xì", "mark_email_read")
}
