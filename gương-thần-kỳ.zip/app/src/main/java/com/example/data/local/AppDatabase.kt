package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        SavedBlessingEntity::class,
        UserInventoryEntity::class,
        ZodiacPetEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun savedBlessingDao(): SavedBlessingDao
    abstract fun userInventoryDao(): UserInventoryDao
    abstract fun zodiacPetDao(): ZodiacPetDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "guong_than_ky.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            val database = getDatabase(context)
                            // Initialize default inventory
                            database.userInventoryDao().saveInventory(UserInventoryEntity())

                            // Initialize default initial saved blessings for the UI
                            val initialBlessings = listOf(
                                SavedBlessingEntity(
                                    id = "tai_loc_di_dom_001",
                                    topic = "tai_loc",
                                    topicName = "Tài lộc",
                                    style = "di_dom",
                                    styleName = "Dí dỏm & Phông bạt",
                                    title = "Tấn tài tấn lộc tân niên vạn phúc",
                                    content = "Nguyện cho gia chủ kim ngân đầy bồ, vạn đường khởi sắc rực rỡ, lộc tấn vinh hoa.",
                                    rhyme = "Rồng cuộn hổ phục mã đáo thành công\nTiền vào như thác đổ • Duyên thắm nồng nàn!",
                                    omen = "ĐẠI CÁT",
                                    code = "#9999-CÁT"
                                ),
                                SavedBlessingEntity(
                                    id = "chua_lanh_nghiem_tuc_001",
                                    topic = "chua_lanh",
                                    topicName = "Chữa lành",
                                    style = "nghiem_tuc",
                                    styleName = "Nghiêm túc & Chân thành",
                                    title = "Tâm an vạn sự hưng, lộc biếc tựa hoa sen",
                                    content = "Thân tâm thanh tịnh tựa ngọc lành, gia đạo yên vui, cát khí phủ tràn bốn mùa.",
                                    rhyme = "Tâm thanh tịnh tựa ngọc lành\nGia đạo yên vui cát khí tràn bốn mùa!",
                                    omen = "THƯỢNG CÁT",
                                    code = "#8888-CÁT"
                                ),
                                SavedBlessingEntity(
                                    id = "dip_nhau_di_dom_001",
                                    topic = "dip_nhau",
                                    topicName = "Dịp nhậu",
                                    style = "di_dom",
                                    styleName = "Dí dỏm & Phông bạt",
                                    title = "Bá đạo không quạu, tiền vào như nước",
                                    content = "Năm mới hoan hỷ, deadline tan biến, sếp quý bạn thương, lương thưởng x5 bùng nổ!",
                                    rhyme = "Bia vàng sủi bọt chào năm mới\nBạn bè hội tụ rộn tiếng cười!",
                                    omen = "CÁT TƯỜNG",
                                    code = "#7777-CÁT"
                                )
                            )
                            initialBlessings.forEach { database.savedBlessingDao().insertBlessing(it) }

                            // Initialize 12 zodiac pets
                            val zodiacs = listOf(
                                ZodiacPetEntity("thin", "Thần Long", "Bảo Long Kim Giáp", "Cực Phẩm", level = 5, cp = 12500, intimacy = 85, fullness = 90, happiness = 95, spiritualEnergy = 80, isCurrentActive = true, isUnlocked = true),
                                ZodiacPetEntity("mao", "Miêu Tài Lộc", "Chiêu Tài Tiên Miêu", "Thượng Phẩm", level = 3, cp = 8200, intimacy = 70, fullness = 80, happiness = 85, spiritualEnergy = 75, isCurrentActive = false, isUnlocked = true),
                                ZodiacPetEntity("tho", "Thỏ Ngọc", "Nguyệt Cung Tiên Thố", "Thần Thoại", level = 2, cp = 9500, intimacy = 65, fullness = 75, happiness = 80, spiritualEnergy = 90, isCurrentActive = false, isUnlocked = true),
                                ZodiacPetEntity("ti", "Linh Thử", "Kim Ngân Phúc Thử", "Quý Hiếm", level = 1, cp = 4500, intimacy = 50, fullness = 70, happiness = 70, spiritualEnergy = 60, isCurrentActive = false, isUnlocked = false),
                                ZodiacPetEntity("suu", "Kim Ngưu", "Trâu Vàng Khởi Vận", "Quý Hiếm", level = 1, cp = 5100, intimacy = 50, fullness = 70, happiness = 70, spiritualEnergy = 60, isCurrentActive = false, isUnlocked = false),
                                ZodiacPetEntity("dan", "Hổ Tướng", "Bạch Hổ Trấn Sơn", "Cực Phẩm", level = 1, cp = 6800, intimacy = 50, fullness = 70, happiness = 70, spiritualEnergy = 60, isCurrentActive = false, isUnlocked = false),
                                ZodiacPetEntity("ty", "Thần Xà", "Kim Xà Ẩn Nguyệt", "Thượng Phẩm", level = 1, cp = 5600, intimacy = 50, fullness = 70, happiness = 70, spiritualEnergy = 60, isCurrentActive = false, isUnlocked = false),
                                ZodiacPetEntity("ngo", "Thiên Mã", "Xích Thố Tung Hoành", "Thần Thoại", level = 1, cp = 7200, intimacy = 50, fullness = 70, happiness = 70, spiritualEnergy = 60, isCurrentActive = false, isUnlocked = false),
                                ZodiacPetEntity("mui", "Linh Dương", "Cát Tường Dương", "Quý Hiếm", level = 1, cp = 4800, intimacy = 50, fullness = 70, happiness = 70, spiritualEnergy = 60, isCurrentActive = false, isUnlocked = false),
                                ZodiacPetEntity("than", "Hầu Vương", "Tề Thiên Thần Hầu", "Thần Thoại", level = 1, cp = 8000, intimacy = 50, fullness = 70, happiness = 70, spiritualEnergy = 60, isCurrentActive = false, isUnlocked = false),
                                ZodiacPetEntity("dau", "Kim Kê", "Kim Kê Báo Hiểu", "Quý Hiếm", level = 1, cp = 4900, intimacy = 50, fullness = 70, happiness = 70, spiritualEnergy = 60, isCurrentActive = false, isUnlocked = false),
                                ZodiacPetEntity("tuat", "Thần Khuyển", "Trung Nghĩa Khuyển", "Quý Hiếm", level = 1, cp = 5000, intimacy = 50, fullness = 70, happiness = 70, spiritualEnergy = 60, isCurrentActive = false, isUnlocked = false),
                                ZodiacPetEntity("hoi", "Phúc Hợi", "Hoàng Kim Trư Bảo", "Cực Phẩm", level = 1, cp = 6200, intimacy = 50, fullness = 70, happiness = 70, spiritualEnergy = 60, isCurrentActive = false, isUnlocked = false)
                            )
                            database.zodiacPetDao().insertAll(zodiacs)
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
