package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SavedBlessingDao {
    @Query("SELECT * FROM saved_blessings ORDER BY savedAt DESC")
    fun getAllSavedBlessings(): Flow<List<SavedBlessingEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBlessing(blessing: SavedBlessingEntity)

    @Query("DELETE FROM saved_blessings WHERE id = :id")
    suspend fun deleteBlessing(id: String)

    @Query("SELECT COUNT(*) FROM saved_blessings")
    fun getSavedCount(): Flow<Int>
}

@Dao
interface UserInventoryDao {
    @Query("SELECT * FROM user_inventory WHERE id = 1")
    fun getInventory(): Flow<UserInventoryEntity?>

    @Query("SELECT * FROM user_inventory WHERE id = 1")
    suspend fun getInventorySnapshot(): UserInventoryEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveInventory(inventory: UserInventoryEntity)

    @Update
    suspend fun updateInventory(inventory: UserInventoryEntity)
}

@Dao
interface ZodiacPetDao {
    @Query("SELECT * FROM zodiac_pets ORDER BY level DESC")
    fun getAllPets(): Flow<List<ZodiacPetEntity>>

    @Query("SELECT * FROM zodiac_pets WHERE isCurrentActive = 1 LIMIT 1")
    fun getActivePet(): Flow<ZodiacPetEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(pets: List<ZodiacPetEntity>)

    @Update
    suspend fun updatePet(pet: ZodiacPetEntity)
}
