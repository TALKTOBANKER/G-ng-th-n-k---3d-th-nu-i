package com.example.data.repository

import android.content.Context
import android.util.JsonReader
import com.example.data.local.AppDatabase
import com.example.data.local.SavedBlessingDao
import com.example.data.local.SavedBlessingEntity
import com.example.data.local.UserInventoryDao
import com.example.data.local.UserInventoryEntity
import com.example.data.local.ZodiacPetDao
import com.example.data.local.ZodiacPetEntity
import com.example.data.model.Blessing
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.io.InputStreamReader
import java.util.zip.GZIPInputStream
import kotlin.random.Random

class BlessingRepository(private val context: Context) {

    private val db = AppDatabase.getDatabase(context)
    val savedBlessingDao: SavedBlessingDao = db.savedBlessingDao()
    val userInventoryDao: UserInventoryDao = db.userInventoryDao()
    val zodiacPetDao: ZodiacPetDao = db.zodiacPetDao()

    val savedBlessings: Flow<List<SavedBlessingEntity>> = savedBlessingDao.getAllSavedBlessings()
    val userInventory: Flow<UserInventoryEntity?> = userInventoryDao.getInventory()
    val allZodiacPets: Flow<List<ZodiacPetEntity>> = zodiacPetDao.getAllPets()
    val activeZodiacPet: Flow<ZodiacPetEntity?> = zodiacPetDao.getActivePet()

    private fun openAssetStream(): InputStream {
        return context.assets.open("blessings.json")
    }

    private val cacheBySegment = java.util.concurrent.ConcurrentHashMap<String, MutableList<Blessing>>()

    init {
        // Pre-warm fallback cache asynchronously
        kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
            try {
                loadInitialCache()
            } catch (_: Exception) {}
        }
    }

    private fun getSegmentKey(topic: String?, style: String?): String {
        val t = topic ?: "tai_loc"
        val s = style ?: "di_dom"
        return "${t}_${s}"
    }

    private fun loadInitialCache() {
        openAssetStream().use { stream ->
            InputStreamReader(stream, "UTF-8").use { reader ->
                JsonReader(reader).use { jsonReader ->
                    jsonReader.beginArray()
                    while (jsonReader.hasNext()) {
                        val blessing = readSingleBlessing(jsonReader)
                        val key = getSegmentKey(blessing.topic, blessing.style)
                        val list = cacheBySegment.computeIfAbsent(key) { java.util.concurrent.CopyOnWriteArrayList() }
                        if (list.size < 25) {
                            list.add(blessing)
                        }
                    }
                    jsonReader.endArray()
                }
            }
        }
    }

    /**
     * Instantly returns a blessing from memory cache or streaming
     */
    suspend fun getRandomBlessing(topic: String?, style: String?): Blessing = withContext(Dispatchers.IO) {
        val key = getSegmentKey(topic, style)
        val cached = cacheBySegment[key]
        if (!cached.isNullOrEmpty()) {
            return@withContext cached.random()
        }

        // If cache not ready yet, read first matching item quickly and return
        var found: Blessing? = null
        try {
            openAssetStream().use { stream ->
                InputStreamReader(stream, "UTF-8").use { reader ->
                    JsonReader(reader).use { jsonReader ->
                        jsonReader.beginArray()
                        var skipTarget = Random.nextInt(20)
                        while (jsonReader.hasNext()) {
                            val blessing = readSingleBlessing(jsonReader)
                            val matchTopic = topic.isNullOrEmpty() || blessing.topic.equals(topic, ignoreCase = true)
                            val matchStyle = style.isNullOrEmpty() || blessing.style.equals(style, ignoreCase = true)
                            if (matchTopic && matchStyle) {
                                val list = cacheBySegment.computeIfAbsent(key) { java.util.concurrent.CopyOnWriteArrayList() }
                                list.add(blessing)
                                if (skipTarget <= 0) {
                                    found = blessing
                                    break
                                }
                                skipTarget--
                            }
                        }
                    }
                }
            }
        } catch (_: Exception) {}

        found ?: fallbackBlessing(topic, style)
    }

    /**
     * Streams and filters blessings with limit and offset.
     */
    suspend fun queryBlessings(
        topic: String?,
        style: String?,
        keyword: String?,
        limit: Int = 30,
        offset: Int = 0
    ): List<Blessing> = withContext(Dispatchers.IO) {
        val result = mutableListOf<Blessing>()
        var skipped = 0

        openAssetStream().use { stream ->
            InputStreamReader(stream, "UTF-8").use { reader ->
                JsonReader(reader).use { jsonReader ->
                    jsonReader.beginArray()
                    while (jsonReader.hasNext() && result.size < limit) {
                        val blessing = readSingleBlessing(jsonReader)
                        val matchTopic = topic.isNullOrEmpty() || blessing.topic.equals(topic, ignoreCase = true)
                        val matchStyle = style.isNullOrEmpty() || blessing.style.equals(style, ignoreCase = true)
                        val matchQuery = keyword.isNullOrBlank() ||
                                blessing.title.contains(keyword, ignoreCase = true) ||
                                blessing.content.contains(keyword, ignoreCase = true) ||
                                blessing.rhyme.contains(keyword, ignoreCase = true)

                        if (matchTopic && matchStyle && matchQuery) {
                            if (skipped < offset) {
                                skipped++
                            } else {
                                result.add(blessing)
                            }
                        }
                    }
                    // Skip remaining to avoid parsing overhead if limit reached
                    while (jsonReader.hasNext()) {
                        jsonReader.skipValue()
                    }
                    jsonReader.endArray()
                }
            }
        }
        result
    }

    private fun readSingleBlessing(reader: JsonReader): Blessing {
        var id = ""
        var topic = ""
        var topicName = ""
        var style = ""
        var styleName = ""
        var title = ""
        var content = ""
        var rhyme = ""
        var omen = "ĐẠI CÁT"
        var code = "#9999-CÁT"

        reader.beginObject()
        while (reader.hasNext()) {
            when (reader.nextName()) {
                "id" -> id = reader.nextString()
                "topic" -> topic = reader.nextString()
                "topicName" -> topicName = reader.nextString()
                "style" -> style = reader.nextString()
                "styleName" -> styleName = reader.nextString()
                "title" -> title = reader.nextString()
                "content" -> content = reader.nextString()
                "rhyme" -> rhyme = reader.nextString()
                "omen" -> omen = reader.nextString()
                "code" -> code = reader.nextString()
                else -> reader.skipValue()
            }
        }
        reader.endObject()

        return Blessing(
            id = id,
            topic = topic,
            topicName = topicName,
            style = style,
            styleName = styleName,
            title = title,
            content = content,
            rhyme = rhyme,
            omen = omen,
            code = code
        )
    }

    private fun fallbackBlessing(topic: String?, style: String?): Blessing {
        return Blessing(
            id = "fallback_001",
            topic = topic ?: "tai_loc",
            topicName = "Tài Lộc",
            style = style ?: "di_dom",
            styleName = "Dí dỏm & Phông bạt",
            title = "Tấn tài tấn lộc tân niên vạn phúc",
            content = "Nguyện cho gia chủ kim ngân đầy bồ, vạn đường khởi sắc rực rỡ, lộc tấn vinh hoa.",
            rhyme = "Rồng cuộn hổ phục mã đáo thành công\nTiền vào như thác đổ • Duyên thắm nồng nàn!",
            omen = "ĐẠI CÁT",
            code = "#9999-CÁT"
        )
    }

    suspend fun saveBlessingToCollection(blessing: Blessing) = withContext(Dispatchers.IO) {
        savedBlessingDao.insertBlessing(
            SavedBlessingEntity(
                id = blessing.id,
                topic = blessing.topic,
                topicName = blessing.topicName,
                style = blessing.style,
                styleName = blessing.styleName,
                title = blessing.title,
                content = blessing.content,
                rhyme = blessing.rhyme,
                omen = blessing.omen,
                code = blessing.code
            )
        )
    }

    suspend fun updateInventory(updater: (UserInventoryEntity) -> UserInventoryEntity) = withContext(Dispatchers.IO) {
        val current = userInventoryDao.getInventorySnapshot() ?: UserInventoryEntity()
        userInventoryDao.saveInventory(updater(current))
    }

    suspend fun updatePet(pet: ZodiacPetEntity) = withContext(Dispatchers.IO) {
        zodiacPetDao.updatePet(pet)
    }
}
