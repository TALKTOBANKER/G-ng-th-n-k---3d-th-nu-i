package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_blessings")
data class SavedBlessingEntity(
    @PrimaryKey val id: String,
    val topic: String,
    val topicName: String,
    val style: String,
    val styleName: String,
    val title: String,
    val content: String,
    val rhyme: String,
    val omen: String,
    val code: String,
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_inventory")
data class UserInventoryEntity(
    @PrimaryKey val id: Int = 1,
    val coins: Int = 8888,
    val luckPercent: Int = 99,
    val goldHammers: Int = 12,
    val nectars: Int = 5,
    val speedupTalismans: Int = 8,
    val heavenlyPeaches: Int = 24,
    val breakTalismans: Int = 88,
    val dailyDrawsLeft: Int = 5,
    val redEnvelopesCount: Int = 3,
    val diamondCount: Int = 1,
    val jadeAmuletCount: Int = 1,
    val incubatorProgress: Int = 75,
    val incubatorSecondsLeft: Int = 9910 // ~2h45m
)

@Entity(tableName = "zodiac_pets")
data class ZodiacPetEntity(
    @PrimaryKey val id: String, // e.g., "thin", "mao", "ty", etc.
    val name: String,
    val title: String,
    val rarity: String, // "Cực Phẩm", "Thần Thoại", etc.
    val level: Int,
    val cp: Int,
    val intimacy: Int, // 0 - 100
    val fullness: Int, // 0 - 100
    val happiness: Int, // 0 - 100
    val spiritualEnergy: Int, // 0 - 100
    val isCurrentActive: Boolean = false,
    val isUnlocked: Boolean = false
)
