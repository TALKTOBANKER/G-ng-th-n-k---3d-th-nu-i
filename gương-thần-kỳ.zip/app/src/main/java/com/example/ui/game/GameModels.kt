package com.example.ui.game

import androidx.compose.ui.graphics.Color

/**
 * 12 Vietnamese Zodiac animals with mythological titles and auspicious descriptions
 */
data class ZodiacSpiritInfo(
    val key: String,
    val name: String,
    val title: String,
    val element: String,
    val blessingSnippet: String,
    val iconEmoji: String,
    val color: Color
)

val ALL_12_ZODIAC_SPIRITS = listOf(
    ZodiacSpiritInfo("ti", "Tí", "Kim Thần Chuột Vàng", "Thủy", "Chiêu tài tấn bảo, vạn sự hanh thông", "🐭", Color(0xFFFDBB2D)),
    ZodiacSpiritInfo("suu", "Sửu", "Kim Ngưu Khởi Vận", "Thổ", "Bền bỉ khai lộc, công danh vững vàng", "🐂", Color(0xFFF59E0B)),
    ZodiacSpiritInfo("dan", "Dần", "Bạch Hổ Thần Uy", "Mộc", "Uy dũng phi thường, đạp sóng vươn xa", "🐯", Color(0xFFEF4444)),
    ZodiacSpiritInfo("mao", "Mão", "Ngọc Miêu Chiêu Tài", "Mộc", "Tài lộc gõ cửa, quý nhân phù trợ", "🐱", Color(0xFF10B981)),
    ZodiacSpiritInfo("thin", "Thìn", "Bảo Long Giáp Thìn", "Thổ", "Rồng vàng thăng thiên, phú quý vô biên", "🐲", Color(0xFFFFD700)),
    ZodiacSpiritInfo("ty", "Tỵ", "Kim Xà Ất Tỵ 2025", "Hỏa", "Lột xác đổi vận, trí tuệ đỉnh cao", "🐍", Color(0xFFE11D48)),
    ZodiacSpiritInfo("ngo", "Ngọ", "Thiên Mã Phi Pha", "Hỏa", "Mã đáo thành công, dặm trường bứt phá", "🐴", Color(0xFFF97316)),
    ZodiacSpiritInfo("mui", "Mùi", "Cát Dương Như Ý", "Thổ", "Gia hòa vạn sự hưng, an khang trường thọ", "🐐", Color(0xFF14B8A6)),
    ZodiacSpiritInfo("than", "Thân", "Linh Hầu Khởi Lộc", "Kim", "Nhanh nhạy nắm bắt cơ duyên vàng", "🐵", Color(0xFF8B5CF6)),
    ZodiacSpiritInfo("dau", "Dậu", "Kim Kê Báo Hỷ", "Kim", "Tiếng gáy vang rền, tin vui dồn dập", "🐔", Color(0xFFFBBF24)),
    ZodiacSpiritInfo("tuat", "Tuất", "Thần Khuyển Hộ Gia", "Thổ", "Trung thành trấn trạch, phúc khí đầy nhà", "🐶", Color(0xFFD97706)),
    ZodiacSpiritInfo("hoi", "Hợi", "Phúc Trư Tụ Tài", "Thủy", "No ấm trọn đời, lộc vàng trút xuống", "🐷", Color(0xFFEC4899))
)

/**
 * 1. Đập Trứng Vàng Game State
 */
data class EggSmashGameState(
    val strikesDone: Int = 0,
    val maxStrikes: Int = 3,
    val selectedZodiacKey: String = "thin",
    val isSwingingHammer: Boolean = false,
    val isEggShaking: Boolean = false,
    val isBroken: Boolean = false,
    val releasedSpirit: ZodiacSpiritInfo? = null,
    val sparkCount: Int = 0,
    val statusMessage: String = "Chạm búa hoặc chạm trứng thần 3 lần để khai mở!"
) {
    val remainingStrikes: Int get() = (maxStrikes - strikesDone).coerceAtLeast(0)
    val crackProgressPercent: Int get() = when (strikesDone) {
        0 -> 0
        1 -> 35
        2 -> 70
        else -> 100
    }
    val currentZodiac: ZodiacSpiritInfo
        get() = ALL_12_ZODIAC_SPIRITS.firstOrNull { it.key == selectedZodiacKey } ?: ALL_12_ZODIAC_SPIRITS[4]
}

/**
 * 2. Gương Kho Báu Game State
 */
data class BaguaSealNode(
    val index: Int,
    val label: String,
    val element: String,
    val isUnlocked: Boolean = false
)

data class TreasureChestGameState(
    val seals: List<BaguaSealNode> = listOf(
        BaguaSealNode(0, "Khai", "Kim", false),
        BaguaSealNode(1, "Nạp", "Mộc", false),
        BaguaSealNode(2, "Tụ", "Thủy", false),
        BaguaSealNode(3, "Phá", "Hỏa", false),
        BaguaSealNode(4, "Hoá Thần", "Thổ", false)
    ),
    val chargePercent: Int = 0, // 0 to 100
    val isOpening: Boolean = false,
    val isOpened: Boolean = false,
    val diamondsAwarded: Int = 2,
    val jadeAwarded: Int = 1,
    val coinsAwarded: Int = 888,
    val statusMessage: String = "Chạm các ấn Bát Quái hoặc chạm rương báu để tích tụ linh khí!"
) {
    val unlockedCount: Int get() = seals.count { it.isUnlocked }
    val isReadyToOpen: Boolean get() = chargePercent >= 100 || unlockedCount >= 5
}

/**
 * 3. Rút Bao Lì Xì Game State
 */
data class LuckyEnvelopeItem(
    val id: Int,
    val name: String,
    val chineseChar: String,
    val coinValue: Int,
    val displayValue: String,
    val blessingTag: String,
    val rotation: Float
)

data class RainParticleItem(
    val id: Int,
    val xRatio: Float,       // 0f..1f (horizontal position)
    val yRatio: Float,       // 0f..1f (vertical position)
    val speed: Float,        // falling speed
    val sizeDp: Float,       // size in dp
    val particleType: ParticleType, // COIN, SYCEE, RED_ENVELOPE, SPARKLE
    val rotation: Float,
    val rotationSpeed: Float
)

enum class ParticleType {
    GOLD_COIN,
    GOLD_SYCEE,
    RED_ENVELOPE,
    SPARKLE
}

data class RedEnvelopeGameState(
    val envelopes: List<LuckyEnvelopeItem> = listOf(
        LuckyEnvelopeItem(1, "Đại Cát", "吉", 88888, "88,888 Xu", "Khai Xuân Đại Cát", -12f),
        LuckyEnvelopeItem(2, "Như Ý", "意", 66666, "66,666 Xu", "Vạn Sự Như Ý", 12f),
        LuckyEnvelopeItem(3, "Phú Quý", "貴", 128888, "128,888 Xu", "Vinh Hoa Phú Quý", -8f),
        LuckyEnvelopeItem(4, "Tài Lộc", "祿", 888888, "888,888 Xu", "Phát Tài Phát Lộc", 8f),
        LuckyEnvelopeItem(5, "An Khang", "康", 99999, "99,999 Xu", "An Khang Thịnh Vượng", -15f),
        LuckyEnvelopeItem(6, "Bình An", "安", 168888, "168,888 Xu", "Tứ Thời Bình An", 14f)
    ),
    val selectedEnvelope: LuckyEnvelopeItem? = null,
    val isDrawn: Boolean = false,
    val isCoinRainActive: Boolean = false,
    val rainParticles: List<RainParticleItem> = emptyList(),
    val shakeIntensity: Float = 0f, // 0f..1f
    val lastShakeGForce: Float = 0f,
    val statusMessage: String = "Lắc điện thoại hoặc chạm bao lì xì để tạo cơn mưa tiền vàng!"
)
