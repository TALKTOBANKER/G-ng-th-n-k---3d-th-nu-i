package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.game.ALL_12_ZODIAC_SPIRITS
import com.example.ui.game.EggSmashGameState
import com.example.ui.theme.CinnabarDeep
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.EmeraldJade
import com.example.ui.theme.EmeraldJadeDark
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldDark
import com.example.ui.theme.ImperialGoldLight
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.MidnightSurfaceHigh
import com.example.ui.theme.MidnightSurfaceLow
import com.example.ui.theme.MidnightSurfaceLowest
import com.example.ui.theme.OnSurfaceText
import com.example.ui.theme.OnSurfaceVariantText

private const val IMG_DRAGON_EGG =
    "https://lh3.googleusercontent.com/aida/AEtjO1Xi_68oQNLZKZzigomtleMYD14sYAtUtuRycVU9n7CrJB8TqOO-vPB-ZBYtirIZW5OXlKKN2UrKRxo7gYmiKE9rI9KY-cmAIOtE3JHOhphINhvp4UBMKrcRdfbkq6OR_fF4McHnly94HxBrGGXti_bBdr5NE_rc8C_CJU_fkP8-nIN2bm266hG9B8CX1awaYFzgEeNmNT8c4ny7Kw8D2lTd5hmXqz3WBHzPdmcPVGoRpX9JqwewTCY62AX_"

@Composable
fun GameEggSmashScreen(
    state: EggSmashGameState,
    coins: Int,
    onStrike: () -> Unit,
    onSelectZodiac: (String) -> Unit,
    onReset: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val hammerRotation = remember { Animatable(-45f) }
    val eggScaleAnim = remember { Animatable(1f) }

    // Listen to strikes / swing events to animate hammer and egg impact
    LaunchedEffect(state.strikesDone) {
        if (state.strikesDone > 0) {
            hammerRotation.animateTo(10f, tween(90, easing = FastOutSlowInEasing))
            eggScaleAnim.animateTo(1.12f, tween(70))
            hammerRotation.animateTo(-55f, tween(110))
            eggScaleAnim.animateTo(1f, tween(90))
            hammerRotation.animateTo(-45f, tween(80))
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "aura")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.55f,
        animationSpec = infiniteRepeatable(tween(1200), RepeatMode.Reverse),
        label = "pulseAlpha"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBackground)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // TOP BANNER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MidnightSurfaceHigh.copy(alpha = 0.9f))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(ImperialGold)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "NGHI THỨC: ĐẬP TRỨNG VÀNG",
                    color = ImperialGold,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onReset,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(MidnightSurfaceLow)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Làm mới",
                        tint = ImperialGold,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(ImperialGoldDark)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Đóng",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // STRIKE COUNTER BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MidnightSurfaceLowest)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = ImperialGold,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "ĐÃ GÕ: ${state.strikesDone} / ${state.maxStrikes} NHỊP",
                    color = OnSurfaceText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (i in 1..state.maxStrikes) {
                    val isDone = i <= state.strikesDone
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .clip(CircleShape)
                            .background(if (isDone) ImperialGold else MidnightSurfaceHigh)
                            .shadow(if (isDone) 6.dp else 0.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 12 ZODIAC SCROLL ROW
        val zodiacScroll = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(zodiacScroll),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            ALL_12_ZODIAC_SPIRITS.forEach { spirit ->
                val isSelected = spirit.key == state.selectedZodiacKey
                Column(
                    modifier = Modifier
                        .testTag("zodiac_${spirit.key}")
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) CinnabarRed else MidnightSurfaceLow)
                        .border(
                            1.dp,
                            if (isSelected) ImperialGold else Color.Transparent,
                            RoundedCornerShape(10.dp)
                        )
                        .clickable { onSelectZodiac(spirit.key) }
                        .padding(horizontal = 8.dp, vertical = 5.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = spirit.iconEmoji, fontSize = 16.sp)
                    Text(
                        text = spirit.name,
                        color = if (isSelected) ImperialGold else OnSurfaceVariantText,
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 3D GOLDEN EGG DISPLAY WITH HAMMER
        Box(
            modifier = Modifier
                .size(260.dp)
                .clip(RoundedCornerShape(20.dp))
                .clickable { onStrike() },
            contentAlignment = Alignment.Center
        ) {
            // Ambient Aura
            Box(
                modifier = Modifier
                    .size(250.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(ImperialGold.copy(alpha = pulseAlpha), Color.Transparent)
                        )
                    )
            )

            // Egg Graphic or Shattered Spirit
            if (!state.isBroken) {
                AsyncImage(
                    model = IMG_DRAGON_EGG,
                    contentDescription = "Trứng Hoàng Kim 3D",
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .scale(eggScaleAnim.value)
                )

                // Visual Crack Overlay when struck
                if (state.strikesDone >= 1) {
                    Box(
                        modifier = Modifier
                            .size(140.dp)
                            .clip(CircleShape)
                            .border(
                                width = (state.strikesDone * 2).dp,
                                color = ImperialGoldLight.copy(alpha = 0.85f),
                                shape = CircleShape
                            )
                    )
                }

                // Animated Hammer Overlay (Top Right)
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .offset(x = (-16).dp, y = 8.dp)
                        .rotate(hammerRotation.value)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(ImperialGold)
                            .border(1.5.dp, Color.White, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = Color(0xFF422D00),
                            modifier = Modifier.size(26.dp)
                        )
                    }
                }
            } else {
                // EGG SHATTERED: RELEASED 12 ZODIAC SPIRIT
                state.releasedSpirit?.let { spirit ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(24.dp))
                            .background(MidnightSurfaceLowest.copy(alpha = 0.95f))
                            .border(2.dp, ImperialGold, RoundedCornerShape(24.dp))
                            .padding(16.dp)
                    ) {
                        Text(text = spirit.iconEmoji, fontSize = 64.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = spirit.title,
                            color = ImperialGold,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Hệ: ${spirit.element} • Đã Giải Phóng Thần Thú",
                            color = EmeraldJade,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "\"${spirit.blessingSnippet}\"",
                            color = OnSurfaceText,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // Hint Pill
            if (!state.isBroken) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .offset(y = (-6).dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(MidnightSurfaceLowest.copy(alpha = 0.85f))
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = EmeraldJade,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Chạm trứng hoặc bấm nút gõ búa!",
                        color = OnSurfaceVariantText,
                        fontSize = 10.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // STATUS MESSAGE BANNER
        Text(
            text = state.statusMessage,
            color = ImperialGoldLight,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        // LINH KHÍ KHAI QUẺ: PROGRESS BAR
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(MidnightSurfaceLow)
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Whatshot,
                        contentDescription = null,
                        tint = EmeraldJade,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Linh Khí Khai Quẻ: ",
                        color = OnSurfaceText,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "${state.crackProgressPercent}%",
                        color = EmeraldJade,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = if (state.remainingStrikes > 0) "CÒN ${state.remainingStrikes} NHỊP" else "ĐÃ GIẢI PHÓNG!",
                    color = ImperialGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Progress bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(MidnightSurfaceLowest)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth((state.crackProgressPercent / 100f).coerceIn(0.05f, 1f))
                        .fillMaxSize()
                        .clip(RoundedCornerShape(5.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(ImperialGoldDark, ImperialGold, EmeraldJade)
                            )
                        )
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // BIG CTA BUTTON: GÕ BÚA
        Button(
            onClick = onStrike,
            enabled = !state.isBroken,
            modifier = Modifier
                .testTag("btn_strike_hammer")
                .fillMaxWidth()
                .height(58.dp)
                .shadow(12.dp, RoundedCornerShape(30.dp)),
            shape = RoundedCornerShape(30.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            if (state.remainingStrikes > 0) listOf(CinnabarRed, CinnabarDeep)
                            else listOf(EmeraldJade, EmeraldJadeDark)
                        )
                    )
                    .border(1.5.dp, ImperialGoldLight, RoundedCornerShape(30.dp)),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Gavel,
                        contentDescription = null,
                        tint = ImperialGold,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.remainingStrikes > 0)
                            "GÕ BÚA (CÒN ${state.remainingStrikes} LẦN)"
                        else "ĐÃ GIẢI PHÓNG THẦN THÚ!",
                        color = ImperialGoldLight,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Stars,
                contentDescription = null,
                tint = ImperialGold,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Khai lộc cùng 12 Linh Thú Hoàng Đạo Đại Cát",
                color = OnSurfaceVariantText,
                fontSize = 11.sp
            )
        }
    }
}
