package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.BookmarkAdd
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Blessing
import com.example.ui.theme.CinnabarDeep
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.EmeraldJade
import com.example.ui.theme.EmeraldJadeDark
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldDark
import com.example.ui.theme.ImperialGoldLight
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.MidnightSurfaceHigh
import com.example.ui.theme.MidnightSurfaceLow
import com.example.ui.theme.OnSurfaceText
import com.example.ui.theme.OnSurfaceVariantText
import com.example.ui.theme.ScrollParchmentDark
import com.example.ui.theme.ScrollParchmentLight
import com.example.ui.theme.ScrollParchmentMid
import com.example.ui.theme.ScrollText

private const val IMG_TIGER =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuBMAs4WlEKnYAlXNKkR3-IqlZlhWFCnWfLIdcr5Y2eqpPk4zPXAXlmBhTIIt4fVMRWkB5fOorzIG7U9c_84WKKF-8K5_wJhdje0DXRFlsx7Nx-Vuyji79I9pDrINue46KoxsoUP_E7iG2t-II15c7N2JpEHWv-_s094JZKwfIIxl-fo2ALxmSowilPQEZNMpenFbNzvtIexVZhS61qMdYJXL4ydfxOtgV9kaJ2d9-fPDI9a_EXCv4KpcQ"

private const val IMG_RABBIT =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuCaaEZqY1qy5ys8G5wexsTqFns1uoJjeS-jFCXxEGx0zfoSK8IBLlrW8esmVi-8KQUF1XTN7OFPwdyacI2wPqNJcuwlG-ZTzKkI45mn3Cx4JmpJYWJjRjtzjLXxwHfbSEhGa5PWySSfZSY8S4b38p5KpDHrdSiohxDd3teBGUHlfOcBwILVmQFtUhl9RX1bjaKPX6ytepMDJ-3UOlQIT9BeAD1AtCMr6yOCroP1lrT58bTGQtriWLUCdA"

private const val IMG_GOLD_SYCEE =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuD0XyV23yFgzOapTVRugpHpx6sfDEP7LbadtIwM7LpYSMyGauOHup7FAuJHdbsczrWFHs41gjMymFnzNzw2yUNCVmeEErinISy0bSWBXvqNUo5KPGSd3GGAnrzUkXtDOaRc-zjzxdQw3-LaOic1KXjAvH7fu0T3DnEfomj00QryXxYWqPhzzoWRmKOi49U2olWbrc5fSp7reTQXBBy4kD8_qPY3lLycgJ4dYmVGkCFC8P60RVZc0Eh78A"

private const val IMG_RED_ENVELOPES =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuCiz9dg2H6Q6LiWytQAvYWVxrqYI7xcvCd8SWj08UeGzcQHXDRHC45zvn9aqA-wyr3DiT8PNm7HwMS-fNE6MtKu5NkKXm09q_ng6dT28vCjcxVk33TUva3XSMjdb0l3NwEDwsV-oN4KoCaV2fKyrt1LSYuS6BjrHLrhuxPzKCRrQjIdncYikJfObyQiUtHZ4xTF-GFbn3xO4tPC-vHn98IeXilNOTj57wls-e2FoMiAiP1NQ-tAYbcXuw"

private const val IMG_DIAMOND =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuACDXbn-8dYib3iqL0-INsdfaOXKrbvj8PhqRbeEtdeIpKv6PrHi0YgtB9U9FGWRxyaB5JIa79_LxuChEtQdnjfBJ1diknh-_ql-vjb83pEqr8_0FbD4rOppXFhXreYM7xVx2K8ZYEo54RDdSNoJHWPBQHY9urRYG8gZcX8tFusbPz5KPVfCABoPpCGhoUQDBZHEapi40PAdz63_jYxZT09KqCGr2ImMsv_uO1gerjenUNJCJuvz1WaqA"

private const val IMG_JADE_AMULET =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuDHv7ViKcI1zVoWVRQF7-lqhjHk50aFOFY3X5GPzCpyleLsefD9eFzU8oVBygD3G9l2U_JsmahY1BS7Hiat0ehA8iWbNZLz1XB3lNsGLrQjyVI11lGHLGnWVTfIw9gSoYcgonpMhEZl0pdm7FQayqucHMYooRRBqrFB6o6CzY19eZgE11UXk4S_4KwbdZrK0T84OLYs3T5TNJ8CCX520rcr4aeTi3Bpz9TkKcB4c1mhc74NwZQhFDUyEw"

@Composable
fun RewardScreen(
    blessing: Blessing?,
    onClaimAndContinue: () -> Unit,
    onSaveToCollection: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val currentBlessing = blessing ?: Blessing(
        id = "fallback",
        topic = "tai_loc",
        topicName = "Tài Lộc",
        style = "di_dom",
        styleName = "Dí dỏm & Phông bạt",
        title = "Tấn tài tấn lộc tân niên vạn phúc",
        content = "Nguyện cho gia chủ kim ngân đầy bồ, vạn đường khởi sắc rực rỡ, lộc tấn vinh hoa.",
        rhyme = "Rồng cuộn hổ phục mã đáo thành công\nTiền vào như thác đổ • Duyên thắm nồng nàn!",
        omen = "ĐẠI CÁT",
        code = "#9999-CÁT"
    )

    fun copyToClipboard() {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val fullText = "${currentBlessing.title}\n${currentBlessing.content}\n${currentBlessing.rhyme} (${currentBlessing.code})"
        val clip = ClipData.newPlainText("Lời chúc may mắn", fullText)
        clipboard?.setPrimaryClip(clip)
    }

    fun shareBlessing() {
        val fullText = "${currentBlessing.title}\n${currentBlessing.content}\n${currentBlessing.rhyme} (${currentBlessing.code})"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Lời Chúc Khai Xuân")
            putExtra(Intent.EXTRA_TEXT, fullText)
        }
        context.startActivity(Intent.createChooser(intent, "Chia sẻ lời chúc"))
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // RITUAL HEADER
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(16.dp))
                .background(MidnightSurfaceHigh)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Stars,
                contentDescription = null,
                tint = ImperialGold,
                modifier = Modifier.size(15.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "THIÊN BAN ĐIỂM LÀNH • KHAI XUÂN ĐẠI CÁT",
                color = ImperialGold,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
                imageVector = Icons.Default.Stars,
                contentDescription = null,
                tint = ImperialGold,
                modifier = Modifier.size(15.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Nghi Thức Khai Quẻ",
            color = ImperialGold,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black
        )
        Text(
            text = "Lộc tụ thiên cung • Gương thần hiển linh cát khí",
            color = OnSurfaceVariantText,
            fontSize = 12.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        // IMPERIAL ROYAL SCROLL (Chiếu Thư Hoàng Gia)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp)
        ) {
            // Top Wooden Roller
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(18.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF381A05), Color(0xFF854D0E), Color(0xFF381A05))
                        )
                    )
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(EmeraldJade)
                )
                Box(
                    modifier = Modifier
                        .height(3.dp)
                        .width(180.dp)
                        .background(ImperialGold.copy(alpha = 0.4f))
                )
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(EmeraldJade)
                )
            }

            // Parchment Body
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = (-4).dp)
                    .clip(RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(ScrollParchmentLight, ScrollParchmentMid, ScrollParchmentDark)
                        )
                    )
                    .padding(horizontal = 14.dp, vertical = 14.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Header inside scroll
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Số Vận: ${currentBlessing.code}",
                            color = ScrollText,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = ScrollText,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "Quẻ ${currentBlessing.omen}",
                                color = ScrollText,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Center with Mascots & Poem
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Tiger Mascot
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, Color(0xFFB45309), CircleShape)
                        ) {
                            AsyncImage(
                                model = IMG_TIGER,
                                contentDescription = "Hổ Hoàng Kim",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }

                        // Wish Title & Rhyme
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = currentBlessing.title,
                                color = ScrollText,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Box(
                                modifier = Modifier
                                    .width(50.dp)
                                    .height(1.dp)
                                    .background(ScrollText.copy(alpha = 0.4f))
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = currentBlessing.rhyme,
                                color = Color(0xFF5E3A00),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center,
                                lineHeight = 16.sp
                            )
                        }

                        // Rabbit Mascot
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, Color(0xFFB45309), CircleShape)
                        ) {
                            AsyncImage(
                                model = IMG_RABBIT,
                                contentDescription = "Thỏ Cung Trăng",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Red Imperial Wax Seal
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .rotate(-8f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color(0xFFDC2626), Color(0xFF991B1B))
                                )
                            )
                            .border(1.dp, ImperialGoldLight, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "ĐẠI",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                lineHeight = 14.sp
                            )
                            Text(
                                text = "CÁT",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                lineHeight = 14.sp
                            )
                        }
                    }
                }
            }

            // Bottom Wooden Roller
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .offset(y = (-6).dp)
                    .height(18.dp)
                    .clip(RoundedCornerShape(9.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF381A05), Color(0xFF854D0E), Color(0xFF381A05))
                        )
                    )
                    .padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(EmeraldJade)
                )
                Box(
                    modifier = Modifier
                        .height(3.dp)
                        .width(180.dp)
                        .background(ImperialGold.copy(alpha = 0.4f))
                )
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(EmeraldJade)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // COPY & SHARE BUTTONS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { copyToClipboard() },
                modifier = Modifier
                    .testTag("btn_copy_blessing")
                    .weight(1f)
                    .height(44.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MidnightSurfaceHigh)
            ) {
                Icon(
                    imageVector = Icons.Default.ContentCopy,
                    contentDescription = null,
                    tint = ImperialGold,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Sao Chép Lời Chúc",
                    color = OnSurfaceText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { shareBlessing() },
                modifier = Modifier
                    .testTag("btn_share_blessing")
                    .weight(1f)
                    .height(44.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MidnightSurfaceHigh)
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = null,
                    tint = ImperialGold,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Chia Sẻ Bạn Bè",
                    color = OnSurfaceText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // RARE REWARDS SECTION (2x2 Grid)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.WorkspacePremium,
                    contentDescription = null,
                    tint = ImperialGold,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Phần Thưởng Quý Hiếm",
                    color = ImperialGold,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(CinnabarRed)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "4 Quà Tặng",
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 2x2 Grid of Rewards
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                RewardBentoItem(
                    category = "TIỀN TỆ",
                    categoryColor = ImperialGold,
                    value = "+500 Vàng",
                    desc = "Lộc Vàng Đầu Năm",
                    imageUrl = IMG_GOLD_SYCEE,
                    modifier = Modifier.weight(1f)
                )
                RewardBentoItem(
                    category = "MAY MẮN",
                    categoryColor = CinnabarRed,
                    value = "+3 Lì Xì Đỏ",
                    desc = "Khai Xuân May Mắn",
                    imageUrl = IMG_RED_ENVELOPES,
                    modifier = Modifier.weight(1f)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                RewardBentoItem(
                    category = "HIẾM CÓ",
                    categoryColor = EmeraldJade,
                    value = "+1 Kim Cương",
                    desc = "Thượng Phẩm Thiên Trúc",
                    imageUrl = IMG_DIAMOND,
                    modifier = Modifier.weight(1f)
                )
                RewardBentoItem(
                    category = "CỰC PHẨM",
                    categoryColor = ImperialGoldLight,
                    value = "+1 Ngọc Bội",
                    desc = "Long Phụng Hộ Mệnh",
                    imageUrl = IMG_JADE_AMULET,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // PRIMARY BUTTON: NHẬN THƯỞNG & CHƠI TIẾP
        Button(
            onClick = onClaimAndContinue,
            modifier = Modifier
                .testTag("btn_claim_continue")
                .fillMaxWidth()
                .height(60.dp)
                .shadow(12.dp, RoundedCornerShape(30.dp)),
            shape = RoundedCornerShape(30.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            listOf(CinnabarRed, Color(0xFFDC2626), ImperialGoldDark)
                        )
                    )
                    .border(1.5.dp, ImperialGoldLight, RoundedCornerShape(30.dp)),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CardGiftcard,
                        contentDescription = null,
                        tint = ImperialGoldLight,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "NHẬN THƯỞNG & CHƠI TIẾP",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // SAVE TO COLLECTION BUTTON
        Row(
            modifier = Modifier
                .clickable { onSaveToCollection() }
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.BookmarkAdd,
                contentDescription = null,
                tint = EmeraldJade,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Lưu vào Kho Lời Chúc Cá Nhân",
                color = OnSurfaceVariantText,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun RewardBentoItem(
    category: String,
    categoryColor: Color,
    value: String,
    desc: String,
    imageUrl: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(MidnightSurfaceLow)
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Start
        ) {
            Text(
                text = category,
                color = categoryColor,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(CircleShape)
                .background(MidnightSurfaceHigh),
            contentAlignment = Alignment.Center
        ) {
            AsyncImage(
                model = imageUrl,
                contentDescription = desc,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = value,
            color = categoryColor,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = desc,
            color = OnSurfaceVariantText,
            fontSize = 10.sp,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}
