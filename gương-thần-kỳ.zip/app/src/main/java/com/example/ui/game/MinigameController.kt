package com.example.ui.game

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

/**
 * Controller managing the complete game loops and interaction states for:
 * 1. Đập Trứng Vàng (Egg smash with 12 Zodiac Spirits)
 * 2. Gương Kho Báu (Bagua celestial seal breaking & treasure chest)
 * 3. Rút Bao Lì Xì (Touch & accelerometer shake with golden coin/envelope shower)
 */
class MinigameController(
    private val context: Context,
    private val scope: CoroutineScope,
    private val onRitualCompleted: (rewardCoins: Int, diamonds: Int, jade: Int, redEnvelopes: Int) -> Unit
) {

    private val vibrator: Vibrator? by lazy {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun triggerHaptic(durationMs: Long = 40, amplitude: Int = VibrationEffect.DEFAULT_AMPLITUDE) {
        try {
            vibrator?.let { v ->
                if (v.hasVibrator()) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        v.vibrate(VibrationEffect.createOneShot(durationMs, amplitude))
                    } else {
                        @Suppress("DEPRECATION")
                        v.vibrate(durationMs)
                    }
                }
            }
        } catch (_: Exception) {}
    }

    // ==========================================
    // 1. ĐẬP TRỨNG VÀNG GAME LOOP
    // ==========================================
    private val _eggState = MutableStateFlow(EggSmashGameState())
    val eggState: StateFlow<EggSmashGameState> = _eggState.asStateFlow()

    fun selectEggZodiac(zodiacKey: String) {
        _eggState.update { it.copy(selectedZodiacKey = zodiacKey) }
        triggerHaptic(20)
    }

    fun strikeEgg() {
        val current = _eggState.value
        if (current.isBroken) return

        val newStrikes = current.strikesDone + 1
        triggerHaptic(60, 200)

        if (newStrikes < current.maxStrikes) {
            // Strike 1 or 2
            val spirit = current.currentZodiac
            val msg = when (newStrikes) {
                1 -> "Nhịp 1: Vết nứt đầu tiên xuất hiện! Khí vận ${spirit.name} đang thức tỉnh!"
                2 -> "Nhịp 2: Kim quang bộc phát mãnh liệt! Gõ thêm 1 nhịp để giải phóng thần thú!"
                else -> "Đang gõ..."
            }

            _eggState.update {
                it.copy(
                    strikesDone = newStrikes,
                    isSwingingHammer = true,
                    isEggShaking = true,
                    sparkCount = it.sparkCount + 1,
                    statusMessage = msg
                )
            }

            scope.launch {
                delay(220)
                _eggState.update { it.copy(isSwingingHammer = false, isEggShaking = false) }
            }
        } else {
            // Strike 3: Break & Release 12 Zodiac Spirit!
            val releasedSpirit = current.currentZodiac
            triggerHaptic(120, 255)

            _eggState.update {
                it.copy(
                    strikesDone = 3,
                    isSwingingHammer = true,
                    isEggShaking = true,
                    isBroken = true,
                    releasedSpirit = releasedSpirit,
                    sparkCount = it.sparkCount + 3,
                    statusMessage = "🎉 TRỨNG THẦN ĐÃ VỠ! Giải phóng Thần Thú ${releasedSpirit.title}!"
                )
            }

            scope.launch {
                delay(300)
                _eggState.update { it.copy(isSwingingHammer = false, isEggShaking = false) }
                delay(1200)
                // Complete game loop and reward
                onRitualCompleted(888, 1, 1, 2)
            }
        }
    }

    fun resetEggGame() {
        _eggState.update {
            EggSmashGameState(selectedZodiacKey = it.selectedZodiacKey)
        }
    }


    // ==========================================
    // 2. GƯƠNG KHO BÁU GAME LOOP
    // ==========================================
    private val _chestState = MutableStateFlow(TreasureChestGameState())
    val chestState: StateFlow<TreasureChestGameState> = _chestState.asStateFlow()

    fun tapBaguaNode(nodeIndex: Int) {
        val current = _chestState.value
        if (current.isOpened || current.isOpening) return

        triggerHaptic(40, 180)
        val updatedSeals = current.seals.map { seal ->
            if (seal.index == nodeIndex) seal.copy(isUnlocked = true) else seal
        }
        val unlockedCount = updatedSeals.count { it.isUnlocked }
        val newCharge = (unlockedCount * 20).coerceAtMost(100)

        val nodeLabel = current.seals.getOrNull(nodeIndex)?.label ?: "Bát Quái"
        val msg = if (newCharge >= 100) {
            "⚡ Đã phá giải trọn vẹn Cửu Trùng Phong Ấn! Chạm MỞ RƯƠNG ngay!"
        } else {
            "Đã khai mở ấn [$nodeLabel]! Tích tụ ${(newCharge)}% linh khí Bát Quái."
        }

        _chestState.update {
            it.copy(
                seals = updatedSeals,
                chargePercent = newCharge,
                statusMessage = msg
            )
        }
    }

    fun touchChestMirror() {
        val current = _chestState.value
        if (current.isOpened || current.isOpening) return

        triggerHaptic(50, 200)
        val nextLockedIndex = current.seals.indexOfFirst { !it.isUnlocked }
        if (nextLockedIndex != -1) {
            tapBaguaNode(nextLockedIndex)
        } else {
            // Already 100% charged, trigger chest open
            openChest()
        }
    }

    fun openChest() {
        val current = _chestState.value
        if (current.isOpened || current.isOpening) return

        triggerHaptic(150, 255)
        _chestState.update {
            it.copy(
                isOpening = true,
                chargePercent = 100,
                statusMessage = "💎 RƯƠNG BÁU PHÁT QUANG! Châu báu kim cương tuôn trào!"
            )
        }

        scope.launch {
            delay(600)
            _chestState.update { it.copy(isOpening = false, isOpened = true) }
            delay(1200)
            // Complete game loop and reward
            onRitualCompleted(1288, 3, 2, 3)
        }
    }

    fun resetChestGame() {
        _chestState.update { TreasureChestGameState() }
    }


    // ==========================================
    // 3. RÚT BAO LÌ XÌ GAME LOOP (TOUCH & ACCELEROMETER)
    // ==========================================
    private val _envelopeState = MutableStateFlow(RedEnvelopeGameState())
    val envelopeState: StateFlow<RedEnvelopeGameState> = _envelopeState.asStateFlow()

    private var coinRainJob: Job? = null
    private var lastShakeTimestamp: Long = 0L

    fun onAccelerometerReading(gForce: Float) {
        val current = _envelopeState.value
        if (current.isDrawn) return

        // Update shake intensity meter (smooth decay/increase)
        val normalizedIntensity = ((gForce - 1.2f) / 1.8f).coerceIn(0f, 1f)
        _envelopeState.update {
            it.copy(
                shakeIntensity = normalizedIntensity,
                lastShakeGForce = gForce
            )
        }

        val now = System.currentTimeMillis()
        if (gForce > 2.2f && (now - lastShakeTimestamp > 1200)) {
            lastShakeTimestamp = now
            triggerHaptic(80, 220)
            triggerCoinRain()
            // Randomly pick an envelope
            val randomEnvelope = current.envelopes.random()
            drawEnvelope(randomEnvelope, isFromShake = true)
        }
    }

    fun simulateShakeGesture() {
        triggerHaptic(70, 200)
        _envelopeState.update { it.copy(shakeIntensity = 1f, lastShakeGForce = 2.8f) }
        triggerCoinRain()
        val randomEnvelope = _envelopeState.value.envelopes.random()
        drawEnvelope(randomEnvelope, isFromShake = true)
    }

    fun selectEnvelopeByTouch(envelope: LuckyEnvelopeItem) {
        val current = _envelopeState.value
        if (current.isDrawn) return

        triggerHaptic(60, 200)
        triggerCoinRain()
        drawEnvelope(envelope, isFromShake = false)
    }

    fun touchPouch() {
        val current = _envelopeState.value
        if (current.isDrawn) return

        triggerHaptic(60, 200)
        triggerCoinRain()
        val randomEnv = current.envelopes.random()
        drawEnvelope(randomEnv, isFromShake = false)
    }

    private fun drawEnvelope(envelope: LuckyEnvelopeItem, isFromShake: Boolean) {
        val msg = if (isFromShake) {
            "📱 LẮC ĐIỆN THOẠI KHỞI SẮC: Nhận Lì Xì [${envelope.name}] - ${envelope.displayValue}!"
        } else {
            "🧧 CHẠM RÚT LÌ XÌ: Mở trúng [${envelope.name}] - ${envelope.displayValue}!"
        }

        _envelopeState.update {
            it.copy(
                selectedEnvelope = envelope,
                isDrawn = true,
                statusMessage = msg
            )
        }

        scope.launch {
            delay(1500)
            // Complete game loop and reward
            onRitualCompleted(envelope.coinValue.coerceAtLeast(888), 1, 1, 5)
        }
    }

    /**
     * Generates active raining gold coins, Sycee and red envelopes
     */
    fun triggerCoinRain(durationMs: Long = 3200) {
        coinRainJob?.cancel()

        // Generate 36 festive rain particles
        val particles = List(36) { index ->
            val pType = when (index % 4) {
                0 -> ParticleType.GOLD_COIN
                1 -> ParticleType.GOLD_SYCEE
                2 -> ParticleType.RED_ENVELOPE
                else -> ParticleType.SPARKLE
            }
            RainParticleItem(
                id = index,
                xRatio = Random.nextFloat(),
                yRatio = -Random.nextFloat() * 0.8f, // start above screen
                speed = 0.015f + Random.nextFloat() * 0.025f,
                sizeDp = 22f + Random.nextFloat() * 18f,
                particleType = pType,
                rotation = Random.nextFloat() * 360f,
                rotationSpeed = (Random.nextFloat() - 0.5f) * 12f
            )
        }

        _envelopeState.update {
            it.copy(
                isCoinRainActive = true,
                rainParticles = particles
            )
        }

        coinRainJob = scope.launch(Dispatchers.Default) {
            val startTime = System.currentTimeMillis()
            while (System.currentTimeMillis() - startTime < durationMs) {
                delay(30) // ~33 FPS particle simulation loop
                _envelopeState.update { current ->
                    if (!current.isCoinRainActive) return@update current
                    val updatedParticles = current.rainParticles.map { p ->
                        val nextY = p.yRatio + p.speed
                        val loopedY = if (nextY > 1.15f) -0.15f else nextY
                        val nextRotation = (p.rotation + p.rotationSpeed) % 360f
                        p.copy(yRatio = loopedY, rotation = nextRotation)
                    }
                    current.copy(rainParticles = updatedParticles)
                }
            }
            _envelopeState.update { it.copy(isCoinRainActive = false, rainParticles = emptyList()) }
        }
    }

    fun resetEnvelopeGame() {
        coinRainJob?.cancel()
        _envelopeState.update {
            RedEnvelopeGameState()
        }
    }
}
