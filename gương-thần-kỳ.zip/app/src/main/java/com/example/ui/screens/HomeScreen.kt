package com.example.ui.screens

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.Screen
import com.example.ui.theme.CinnabarDeep
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.CinnabarRedDark
import com.example.ui.theme.CinnabarRedLight
import com.example.ui.theme.EmeraldJade
import com.example.ui.theme.EmeraldJadeDark
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldDark
import com.example.ui.theme.ImperialGoldLight
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.MidnightSurfaceHigh
import com.example.ui.theme.MidnightSurfaceLowest
import com.example.ui.theme.OnSurfaceText
import com.example.ui.theme.OnSurfaceVariantText

private const val MIRROR_IMAGE_URL =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuC7S74-kDFITS1JaZOprGN7Ak2vnTm9LraCCJJvMiQdGl1YrEcDMLdfx6S3Lu6eZRRiWrrZxygbbimIwYLF21gcQRwIurDmBKCuCB7Eq1faeuS8TI-WpYeFjF7PVhOStPl-UaluzRsfK3ojH6ORp2cHA62ooCevmmfnp1olYUWGLc868gX8_tyE1bAPoauQQtRrVMm4TzXqR3KcIk7gc7UUqxCPgra5iXBk2fl7ty9Y8b1jcdp9V395Ag"

@Composable
fun HomeScreen(
    coins: Int,
    onStartRitual: () -> Unit,
    onDailyGiftClick: () -> Unit,
    onLibraryClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onMirrorTap: () -> Unit,
    onPlayEggSmash: () -> Unit = {},
    onPlayTreasureChest: () -> Unit = {},
    onPlayRedEnvelope: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // TOP STATUS BAR
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Auspicious Year & Qi Badge
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(MidnightSurfaceHigh.copy(alpha = 0.9f))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(CinnabarRed),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "巳",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "Ất Tỵ 2025",
                        color = ImperialGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(5.dp)
                                .clip(CircleShape)
                                .background(EmeraldJade)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = "Khí Vận 99%",
                            color = EmeraldJade,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Coin pill
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(MidnightSurfaceLowest)
                    .padding(start = 6.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.verticalGradient(listOf(ImperialGoldLight, ImperialGoldDark))
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.MonetizationOn,
                        contentDescription = null,
                        tint = Color(0xFF422D00),
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Xu Phúc",
                        color = OnSurfaceVariantText,
                        fontSize = 9.sp
                    )
                    Text(
                        text = String.format("%,d", coins),
                        color = ImperialGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Box(
                    modifier = Modifier
                        .size(22.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.verticalGradient(listOf(ImperialGold, ImperialGoldDark))
                        )
                        .clickable { onDailyGiftClick() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Thêm xu",
                        tint = Color(0xFF422D00),
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // TITLE SECTION
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(MidnightSurfaceHigh.copy(alpha = 0.5f))
                .padding(horizontal = 12.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = ImperialGold,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "HUYỀN CƠ KHỞI VẬN",
                color = ImperialGold,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = ImperialGold,
                modifier = Modifier.size(13.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "GƯƠNG THẦN KỲ",
            color = ImperialGold,
            fontSize = 28.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 2.sp,
            textAlign = TextAlign.Center
        )

        Text(
            text = "LỜI CHÚC MAY MẮN • KHAI XUÂN ĐẮC LỘC",
            color = CinnabarRedLight,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.8.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(16.dp))

        // CENTERPIECE: Mythic Golden Mirror with 5 Elements
        Box(
            modifier = Modifier
                .size(290.dp)
                .scale(pulseScale)
                .clickable {
                    onMirrorTap()
                    onStartRitual()
                },
            contentAlignment = Alignment.Center
        ) {
            // Ambient halo
            Box(
                modifier = Modifier
                    .size(280.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                ImperialGold.copy(alpha = 0.25f),
                                CinnabarRed.copy(alpha = 0.15f),
                                Color.Transparent
                            )
                        )
                    )
            )

            // Carved golden frame
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(
                            listOf(ImperialGoldLight, ImperialGoldDark, Color(0xFF472D00))
                        )
                    )
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                // Jade inner bevel
                Box(
                    modifier = Modifier
                        .size(244.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.verticalGradient(listOf(EmeraldJade, EmeraldJadeDark))
                        )
                        .padding(8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    // Mirror Glass surface
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    ) {
                        AsyncImage(
                            model = MIRROR_IMAGE_URL,
                            contentDescription = "Gương Thần Chiếu Mệnh",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // Shimmer overlay
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        listOf(
                                            Color.Transparent,
                                            MidnightBackground.copy(alpha = 0.65f)
                                        )
                                    )
                                )
                        )

                        // Tap mirror indicator tag
                        Row(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .offset(y = (-14).dp)
                                .clip(RoundedCornerShape(20.dp))
                                .background(MidnightSurfaceLowest.copy(alpha = 0.85f))
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = null,
                                tint = ImperialGold,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "CHẠM GƯƠNG ĐỂ SOI VẬN",
                                color = ImperialGoldLight,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }
                }
            }

            // 5 Elements (Ngũ Hành) Badges around Mirror Frame
            // 1. Kim (Top Center)
            ElementBadge(
                name = "Kim",
                color = ImperialGold,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = 2.dp)
            )

            // 2. Mộc (Top Right)
            ElementBadge(
                name = "Mộc",
                color = EmeraldJade,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-16).dp, y = 48.dp)
            )

            // 3. Thủy (Bottom Right)
            ElementBadge(
                name = "Thủy",
                color = Color(0xFF38BDF8),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = (-18).dp, y = (-48).dp)
            )

            // 4. Hỏa (Bottom Left)
            ElementBadge(
                name = "Hỏa",
                color = CinnabarRed,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .offset(x = 18.dp, y = (-48).dp)
            )

            // 5. Thổ (Top Left)
            ElementBadge(
                name = "Thổ",
                color = Color(0xFFF59E0B),
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 16.dp, y = 48.dp)
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // PRIMARY ACTION BUTTON: BẮT ĐẦU CHƠI
        Button(
            onClick = onStartRitual,
            modifier = Modifier
                .testTag("btn_start_game")
                .fillMaxWidth()
                .height(64.dp)
                .shadow(12.dp, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            listOf(CinnabarRed, Color(0xFFFF3B4B), ImperialGoldDark)
                        )
                    )
                    .border(
                        1.5.dp,
                        Brush.horizontalGradient(listOf(ImperialGoldLight, Color.White, ImperialGoldLight)),
                        RoundedCornerShape(32.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = ImperialGoldLight,
                        modifier = Modifier
                            .size(24.dp)
                            .scale(scaleX = -1f, scaleY = 1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "BẮT ĐẦU CHƠI",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = ImperialGoldLight,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // QUICK MINIGAMES STRIP
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MINIGAME KHUI QUÀ",
                color = ImperialGold,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Text(
                text = "Chơi Ngay",
                color = EmeraldJade,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Minigame 1: Đập Trứng
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MidnightSurfaceHigh)
                    .border(1.dp, CinnabarRed.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .clickable { onPlayEggSmash() }
                    .padding(vertical = 10.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "🔨", fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Đập Trứng",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "12 Linh Thú",
                        color = ImperialGold,
                        fontSize = 9.sp
                    )
                }
            }

            // Minigame 2: Gương Kho Báu
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MidnightSurfaceHigh)
                    .border(1.dp, ImperialGold.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .clickable { onPlayTreasureChest() }
                    .padding(vertical = 10.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "✨", fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Gương Báu",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Mở Rương Vàng",
                        color = ImperialGold,
                        fontSize = 9.sp
                    )
                }
            }

            // Minigame 3: Rút Bao Lì Xì
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MidnightSurfaceHigh)
                    .border(1.dp, EmeraldJade.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .clickable { onPlayRedEnvelope() }
                    .padding(vertical = 10.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = "🧧", fontSize = 20.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Rút Lì Xì",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Chạm / Lắc Tay",
                        color = EmeraldJade,
                        fontSize = 9.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // 3 UTILITY BUTTONS
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            // 1. Quà Tết
            UtilityCircleButton(
                icon = Icons.Default.CardGiftcard,
                label = "Quà Tết",
                badge = "1",
                tint = ImperialGold,
                onClick = onDailyGiftClick,
                modifier = Modifier.testTag("btn_daily_gift")
            )

            // 2. Kho Phúc (Browse 7.200 blessings)
            UtilityCircleButton(
                icon = Icons.Default.HistoryEdu,
                label = "Kho Phúc",
                tint = EmeraldJade,
                onClick = onLibraryClick,
                modifier = Modifier.testTag("btn_browse_library")
            )

            // 3. Cài Đặt
            UtilityCircleButton(
                icon = Icons.Default.Settings,
                label = "Cài Đặt",
                tint = OnSurfaceVariantText,
                onClick = onSettingsClick,
                modifier = Modifier.testTag("btn_settings")
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun ElementBadge(
    name: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .size(28.dp)
            .clip(CircleShape)
            .background(color)
            .shadow(4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = name,
            color = Color.Black,
            fontSize = 10.sp,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
fun UtilityCircleButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    badge: String? = null,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(
                            listOf(MidnightSurfaceHigh, MidnightSurfaceLowest)
                        )
                    )
                    .border(1.dp, tint.copy(alpha = 0.5f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = tint,
                    modifier = Modifier.size(26.dp)
                )
            }

            if (badge != null) {
                Box(
                    modifier = Modifier
                        .offset(x = 2.dp, y = (-2).dp)
                        .size(18.dp)
                        .clip(CircleShape)
                        .background(CinnabarRed),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = badge,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = label,
            color = OnSurfaceText,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold
        )
    }
}
