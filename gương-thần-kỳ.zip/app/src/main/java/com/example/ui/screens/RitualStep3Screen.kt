package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Egg
import androidx.compose.material.icons.filled.Hardware
import androidx.compose.material.icons.filled.HotelClass
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.MarkEmailRead
import androidx.compose.material.icons.filled.MarkEmailUnread
import androidx.compose.material.icons.filled.Redeem
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Token
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.RitualType
import com.example.ui.theme.CinnabarDeep
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.EmeraldJade
import com.example.ui.theme.EmeraldJadeDark
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldDark
import com.example.ui.theme.ImperialGoldLight
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.MidnightSurfaceHigh
import com.example.ui.theme.MidnightSurfaceLow
import com.example.ui.theme.MidnightSurfaceLowest
import com.example.ui.theme.OnSurfaceText
import com.example.ui.theme.OnSurfaceVariantText

private const val IMG_EGG_PREVIEW =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuDNqiNUAVHq4pkyBge6L5mOKvxyNq_nOcs75CbhGx9c-J80xfBIBwHx6SZrF_77--b-GziXJBvZW1Hw_4TkYjXTwEhsBUvY_xpbeuNPLezsGMtZQa5_-ZwJKXZsV8qmHjuedDcIFPJYEw19DIE_Iz7m_BOIfb1TqeNDrStqMzqcj3wDYOVyo3gUnhjKlh2eIypBcfaIeoorWf0NnPGJGW82_D1XbgdhzfGNQUA3rUAsgZiFQTWtobplPA"

private const val IMG_CHEST_PREVIEW =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuC736pPaxJ_xCmiq4d5UImpJe8Jp7WasLqgc6XH8_atu3rAJLCpm5XRHVVhZ2rYDYipo01oX2z0u6wr5i3h4Cpba08LgkpBt31Zl9fFvUiuFBp5AKKR5wbkJiLQ8FtnL96ykKb_QM3es8__fvWq-PGWTgfDca0e0EVszOKTa4wlYGJeh5eMAhlfcBX8mdxpiwqvXkXjccGVYmKVV7r4WexcSEQpeXldp0JHs_g4ny8h9bl6cMtWtQ9IOQ"

private const val IMG_ENVELOPE_PREVIEW =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuCtJiSQWY_IPaTSRJCofCFbHrKVELQQ6Y9fJ5HDIzZfPK8TWbn5GINAHi0SiWzZkwtSB2WbY_dL0sbHR-IjoWEl1v8doEyocnWeO97S57MmEl_5CS50_Gu6gtYDg6RGTlVkgI8aJ1We07qGuqjhhIEXmHi2dKByCSQIMjUcRF3-FNRJLNBAAwvAhiJBe-PQlfTu2XCtdVsFN9HmZLMUtBPCi3OFigR6rtnjYolL71KzyBdUhkkcyLRqLg"

@Composable
fun RitualStep3Screen(
    onSelectRitual: (RitualType) -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // PROGRESS HEADER (100% COMPLETE)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = ImperialGold,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "BƯỚC 3 / 3: CHỌN PHÁP BẢO KHUI LỘC",
                    color = ImperialGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(MidnightSurfaceHigh)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = "100% HOÀN TẤT",
                    color = EmeraldJade,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Full Progress Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(ImperialGold, CinnabarRed, ImperialGoldLight)
                    )
                )
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Guidance banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(MidnightSurfaceLow)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = ImperialGold,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "Chọn 1 trong 3 nghi thức thần bí để phá niêm phong lời chúc phúc hôm nay!",
                color = OnSurfaceText,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }

        Spacer(modifier = Modifier.height(18.dp))

        // CARD 1: ĐẬP TRỨNG VÀNG
        RitualCard(
            ritualNumber = "Bí Kíp 01",
            title = "ĐẬP TRỨNG VÀNG",
            badgeText = "CỰC HOT • Mở 12 Con Giáp",
            badgeColor = CinnabarRed,
            badgeIcon = Icons.Default.LocalFireDepartment,
            secondBadge = "Uy Lực x3",
            imageUrl = IMG_EGG_PREVIEW,
            footerLeft = "Tỷ lệ Thần Thú: 88%",
            footerLeftIcon = Icons.Default.Token,
            footerRight = "Tặng búa ngọc",
            buttonText = "🔨 CHỌN KHUI >",
            buttonBrush = Brush.verticalGradient(listOf(Color(0xFFF43648), Color(0xFFB21222))),
            onChoose = { onSelectRitual(RitualType.EGG_SMASH) },
            modifier = Modifier.testTag("ritual_egg_smash")
        )

        Spacer(modifier = Modifier.height(18.dp))

        // CARD 2: GƯƠNG KHO BÁU
        RitualCard(
            ritualNumber = "Bí Kíp 02",
            title = "GƯƠNG KHO BÁU",
            badgeText = "BÍ ẨN • Châu Báu Ngàn Năm",
            badgeColor = ImperialGoldDark,
            badgeIcon = Icons.Default.LockOpen,
            secondBadge = null,
            imageUrl = IMG_CHEST_PREVIEW,
            footerLeft = "Điềm Lành Thượng Hạng",
            footerLeftIcon = Icons.Default.WorkspacePremium,
            footerRight = "Tặng 500 Xu",
            buttonText = "✨ CHỌN KHUI >",
            buttonBrush = Brush.verticalGradient(listOf(Color(0xFFFDBB2D), Color(0xFFB87B00))),
            onChoose = { onSelectRitual(RitualType.TREASURE_CHEST) },
            modifier = Modifier.testTag("ritual_treasure_chest")
        )

        Spacer(modifier = Modifier.height(18.dp))

        // CARD 3: RÚT BAO LÌ XÌ
        RitualCard(
            ritualNumber = "Bí Kíp 03",
            title = "RÚT BAO LÌ XÌ",
            badgeText = "TÀI LỘC • Chạm Hoặc Lắc Máy",
            badgeColor = EmeraldJadeDark,
            badgeIcon = Icons.Default.Redeem,
            secondBadge = "Cảm Ứng Lắc",
            imageUrl = IMG_ENVELOPE_PREVIEW,
            footerLeft = "Lộc Bất Tận: 99.9%",
            footerLeftIcon = Icons.Default.CardGiftcard,
            footerRight = "Rút tức thì",
            buttonText = "🧧 CHỌN KHUI >",
            buttonBrush = Brush.verticalGradient(listOf(Color(0xFF22A87F), Color(0xFF116147))),
            onChoose = { onSelectRitual(RitualType.RED_ENVELOPE) },
            modifier = Modifier.testTag("ritual_red_envelope")
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Bottom Ready Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MidnightSurfaceHigh)
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(MidnightSurfaceLowest)
                    .border(1.dp, ImperialGold, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = null,
                    tint = ImperialGold,
                    modifier = Modifier.size(26.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = ImperialGold,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Pháp Bảo Vận Khí Đã Sẵn Sàng",
                        color = ImperialGold,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Linh lực đã được tụ đỉnh 100%. Quẻ chúc của bạn sẽ được kích hoạt cùng phước lành cát tường.",
                    color = OnSurfaceVariantText,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun RitualCard(
    ritualNumber: String,
    title: String,
    badgeText: String,
    badgeColor: Color,
    badgeIcon: androidx.compose.ui.graphics.vector.ImageVector,
    secondBadge: String?,
    imageUrl: String,
    footerLeft: String,
    footerLeftIcon: androidx.compose.ui.graphics.vector.ImageVector,
    footerRight: String,
    buttonText: String,
    buttonBrush: Brush,
    onChoose: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(MidnightSurface)
            .border(1.dp, Color(0xFF3B304A), RoundedCornerShape(18.dp))
            .clickable { onChoose() }
            .padding(14.dp)
    ) {
        Column {
            // Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(badgeColor)
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = badgeIcon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = badgeText,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                if (secondBadge != null) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .background(MidnightSurfaceHigh)
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = secondBadge,
                            color = ImperialGoldLight,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Title
            Text(
                text = ritualNumber.uppercase(),
                color = OnSurfaceVariantText,
                fontSize = 10.sp,
                letterSpacing = 1.sp
            )
            Text(
                text = title,
                color = ImperialGold,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Image Preview Container
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MidnightSurfaceLowest)
            ) {
                AsyncImage(
                    model = imageUrl,
                    contentDescription = title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Overlay gradient
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, MidnightSurfaceLowest.copy(alpha = 0.85f))
                            )
                        )
                )

                // Bottom floating info
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MidnightSurfaceLowest.copy(alpha = 0.75f))
                            .padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = footerLeftIcon,
                            contentDescription = null,
                            tint = ImperialGold,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = footerLeft,
                            color = OnSurfaceText,
                            fontSize = 10.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MidnightSurfaceLowest.copy(alpha = 0.75f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = footerRight,
                            color = ImperialGold,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Action Button
            Button(
                onClick = onChoose,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .shadow(6.dp, RoundedCornerShape(24.dp)),
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(buttonBrush)
                        .border(1.dp, ImperialGoldLight.copy(alpha = 0.5f), RoundedCornerShape(24.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = buttonText,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}
