package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.Cyclone
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material.icons.filled.Flare
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.LockReset
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Stream
import androidx.compose.material.icons.filled.Toll
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.game.TreasureChestGameState
import com.example.ui.theme.CinnabarDeep
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.EmeraldJade
import com.example.ui.theme.EmeraldJadeDark
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldDark
import com.example.ui.theme.ImperialGoldLight
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.MidnightSurfaceHigh
import com.example.ui.theme.MidnightSurfaceLow
import com.example.ui.theme.MidnightSurfaceLowest
import com.example.ui.theme.OnSurfaceText
import com.example.ui.theme.OnSurfaceVariantText

private const val IMG_TREASURE_CHEST =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuA0dmbm--sq5LRxdwj3kzJjaBo0cpgSMnnvElrZGFeiJ7qC9XFYhvgAi2SjEtVUMbvkvI6fHBKhhO1k01p679U3XbgaMHawpdlZ57vwoCZMXZBR7IEzEa91wZvCpyn29tyi_Uj6mnlnfCfyfTw9gfh76IfhEEWg-_huTd7sD-5HO1Z7cGuT_hzSuAjgE9RZj09YM4mk1BxPln2SjSEiBgwnCGE1UQcrFKl9NMntRKTv30lZNoPKXR8lhA"

@Composable
fun GameTreasureChestScreen(
    state: TreasureChestGameState,
    coins: Int,
    onTapNode: (Int) -> Unit,
    onTouchChest: () -> Unit,
    onOpenChest: () -> Unit,
    onReset: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val chestScale = remember { Animatable(1f) }

    LaunchedEffect(state.chargePercent) {
        chestScale.animateTo(1.08f, tween(100))
        chestScale.animateTo(1f, tween(100))
    }

    val infiniteTransition = rememberInfiniteTransition(label = "chestAura")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.25f,
        targetValue = 0.6f,
        animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulseAlpha"
    )
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(16000, easing = androidx.compose.animation.core.LinearEasing)),
        label = "ringRotation"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // TOP BANNER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MidnightSurfaceHigh)
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = ImperialGold,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "GƯƠNG KHO BÁU HOÀNG KIM",
                    color = ImperialGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onReset,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(MidnightSurfaceLow)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Làm mới",
                        tint = ImperialGold,
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(ImperialGoldDark)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Đóng",
                        tint = Color.White,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // MYSTIC CENTERPIECE: CHEST DISPLAY WITH BAGUA ENERGY
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(280.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(MidnightSurfaceLowest)
                .clickable { onTouchChest() },
            contentAlignment = Alignment.Center
        ) {
            // Ambient Radial Halo
            Box(
                modifier = Modifier
                    .size(260.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                ImperialGold.copy(alpha = pulseAlpha),
                                EmeraldJade.copy(alpha = 0.2f),
                                Color.Transparent
                            )
                        )
                    )
            )

            // Rotating Bagua energy ring
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .rotate(ringRotation)
                    .border(
                        1.5.dp,
                        Brush.sweepGradient(listOf(ImperialGold, EmeraldJade, Color.Transparent, ImperialGold)),
                        CircleShape
                    )
            )

            // 3D Chest Graphic or Open Treasure Blast
            if (!state.isOpened) {
                AsyncImage(
                    model = IMG_TREASURE_CHEST,
                    contentDescription = "Rương Kho Báu Hoàng Kim",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxSize()
                        .scale(chestScale.value)
                )

                // Central Qi touch target
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape)
                        .background(ImperialGold.copy(alpha = 0.85f))
                        .shadow(12.dp, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (state.isReadyToOpen) Icons.Default.LockOpen else Icons.Default.Toll,
                        contentDescription = null,
                        tint = Color(0xFF422D00),
                        modifier = Modifier.size(28.dp)
                    )
                }
            } else {
                // CHEST BURST OPEN: GEMSTONES & DIAMONDS
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MidnightSurfaceLowest.copy(alpha = 0.95f))
                        .padding(16.dp)
                ) {
                    Text(text = "💎 ✨ 👑", fontSize = 42.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "PHONG ẤN ĐÃ MỞ!",
                        color = ImperialGold,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "+${state.diamondsAwarded} Kim Cương • +${state.jadeAwarded} Ngọc Bội • +${state.coinsAwarded} Xu",
                        color = EmeraldJade,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Top Floating Qi Tag
            Row(
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 12.dp, y = 12.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MidnightSurfaceLowest.copy(alpha = 0.85f))
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Stars,
                    contentDescription = null,
                    tint = EmeraldJade,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Khí Vận: ${state.chargePercent}%",
                    color = EmeraldJade,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Bottom Hint
            if (!state.isOpened) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .offset(y = (-8).dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(MidnightSurfaceLowest.copy(alpha = 0.85f))
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = ImperialGold,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Chạm rương báu hoặc các ấn bên dưới để tích tụ linh khí",
                        color = OnSurfaceVariantText,
                        fontSize = 10.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // STATUS MESSAGE
        Text(
            text = state.statusMessage,
            color = ImperialGoldLight,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(10.dp))

        // SEAL BREAKING PROGRESS BAR
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(MidnightSurfaceHigh)
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (state.isReadyToOpen) Icons.Default.LockOpen else Icons.Default.Lock,
                        contentDescription = null,
                        tint = ImperialGold,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "TIẾN TRÌNH GIẢI ẤN BÁT QUÁI",
                        color = ImperialGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "${state.chargePercent}% / 100%",
                    color = if (state.isReadyToOpen) EmeraldJade else CinnabarRed,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(MidnightSurfaceLowest)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth((state.chargePercent / 100f).coerceIn(0.05f, 1f))
                        .fillMaxSize()
                        .clip(RoundedCornerShape(5.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(CinnabarRed, ImperialGold, EmeraldJade)
                            )
                        )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 5 INTERACTIVE BAGUA SEAL NODES
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            val nodeIcons = listOf(
                Icons.Default.Flare,
                Icons.Default.Compress,
                Icons.Default.Stream,
                Icons.Default.Cyclone,
                Icons.Default.LockReset
            )
            state.seals.forEachIndexed { i, seal ->
                BaguaNodeItem(
                    label = seal.label,
                    element = seal.element,
                    icon = nodeIcons.getOrElse(i) { Icons.Default.AutoAwesome },
                    isUnlocked = seal.isUnlocked,
                    onClick = { onTapNode(seal.index) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // PRIMARY ACTION BUTTON: CHẠM MỞ RƯƠNG
        Button(
            onClick = {
                if (state.isReadyToOpen) onOpenChest() else onTouchChest()
            },
            enabled = !state.isOpened,
            modifier = Modifier
                .testTag("btn_open_chest")
                .fillMaxWidth()
                .height(60.dp)
                .shadow(12.dp, RoundedCornerShape(30.dp)),
            shape = RoundedCornerShape(30.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            if (state.isReadyToOpen) listOf(ImperialGoldDark, ImperialGold, EmeraldJade)
                            else listOf(CinnabarRed, CinnabarDeep)
                        )
                    )
                    .border(1.5.dp, ImperialGoldLight, RoundedCornerShape(30.dp)),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (state.isReadyToOpen) Icons.Default.Diamond else Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = if (state.isReadyToOpen) Color(0xFF422D00) else ImperialGoldLight,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (state.isOpened) "ĐÃ MỞ RƯƠNG BÁU!"
                        else if (state.isReadyToOpen) "CHẠM MỞ RƯƠNG BÁU HOÀNG KIM!"
                        else "TÍCH TỤ LINH KHÍ (${state.chargePercent}%)",
                        color = if (state.isReadyToOpen) Color(0xFF422D00) else ImperialGoldLight,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun BaguaNodeItem(
    label: String,
    element: String,
    icon: ImageVector,
    isUnlocked: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .testTag("bagua_node_$label")
            .clip(RoundedCornerShape(12.dp))
            .background(if (isUnlocked) MidnightSurfaceHigh else MidnightSurfaceLow)
            .border(
                1.5.dp,
                if (isUnlocked) ImperialGold else MidnightSurfaceLowest,
                RoundedCornerShape(12.dp)
            )
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(34.dp)
                .clip(CircleShape)
                .background(if (isUnlocked) ImperialGold else MidnightSurfaceLowest),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isUnlocked) Color(0xFF422D00) else OnSurfaceVariantText,
                modifier = Modifier.size(18.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            color = if (isUnlocked) ImperialGold else OnSurfaceText,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = if (isUnlocked) "Đạt" else element,
            color = if (isUnlocked) EmeraldJade else OnSurfaceVariantText,
            fontSize = 9.sp
        )
    }
}
