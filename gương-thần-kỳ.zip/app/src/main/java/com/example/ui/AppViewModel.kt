package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.SavedBlessingEntity
import com.example.data.local.UserInventoryEntity
import com.example.data.local.ZodiacPetEntity
import com.example.data.model.Blessing
import com.example.data.model.RitualType
import com.example.data.repository.BlessingRepository
import com.example.ui.game.EggSmashGameState
import com.example.ui.game.MinigameController
import com.example.ui.game.RedEnvelopeGameState
import com.example.ui.game.TreasureChestGameState
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AppTab(val title: String, val iconName: String) {
    HOME("Gương Thần", "flare"),
    INCUBATOR("Ấp Trứng", "egg"),
    PETS("Linh Thú", "pets"),
    INVENTORY("Túi Đồ", "inventory_2")
}

sealed interface Screen {
    data class TabView(val tab: AppTab) : Screen
    data object RitualStep1 : Screen
    data object RitualStep2 : Screen
    data object RitualStep3 : Screen
    data object GameEggSmash : Screen
    data object GameTreasureChest : Screen
    data object GameRedEnvelope : Screen
    data object Reward : Screen
    data object LibrarySearch : Screen
}

data class UiState(
    val currentScreen: Screen = Screen.TabView(AppTab.HOME),
    val activeTab: AppTab = AppTab.HOME,
    val selectedStyle: String = "di_dom", // "di_dom" or "nghiem_tuc"
    val humorLevel: Int = 5,
    val selectedTopic: String = "tai_loc",
    val selectedRitual: RitualType = RitualType.EGG_SMASH,
    val currentBlessing: Blessing? = null,
    val toastMessage: String? = null,

    // Incubator
    val incubatorSeconds: Int = 9910,
    val incubatorCrack: Int = 75,

    // Search / Library
    val libraryFilterTopic: String? = null,
    val libraryFilterStyle: String? = null,
    val librarySearchQuery: String = "",
    val libraryResults: List<Blessing> = emptyList(),
    val isLibraryLoading: Boolean = false
)

class AppViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BlessingRepository(application)

    val gameController = MinigameController(
        context = application,
        scope = viewModelScope,
        onRitualCompleted = { coins, diamonds, jade, envelopes ->
            viewModelScope.launch {
                completeRitualAndAward(coins, diamonds, jade, envelopes)
            }
        }
    )

    val eggGameState: StateFlow<EggSmashGameState> = gameController.eggState
    val chestGameState: StateFlow<TreasureChestGameState> = gameController.chestState
    val envelopeGameState: StateFlow<RedEnvelopeGameState> = gameController.envelopeState

    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    val savedBlessings: StateFlow<List<SavedBlessingEntity>> = repository.savedBlessings
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val userInventory: StateFlow<UserInventoryEntity?> = repository.userInventory
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserInventoryEntity())

    val allZodiacPets: StateFlow<List<ZodiacPetEntity>> = repository.allZodiacPets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeZodiacPet: StateFlow<ZodiacPetEntity?> = repository.activeZodiacPet
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    private var countdownJob: Job? = null

    init {
        startIncubatorCountdown()
    }

    private fun startIncubatorCountdown() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _uiState.update { current ->
                    if (current.incubatorSeconds > 0) {
                        current.copy(incubatorSeconds = current.incubatorSeconds - 1)
                    } else current
                }
            }
        }
    }

    fun navigateToTab(tab: AppTab) {
        _uiState.update {
            it.copy(
                activeTab = tab,
                currentScreen = Screen.TabView(tab)
            )
        }
    }

    fun navigateToScreen(screen: Screen) {
        when (screen) {
            Screen.GameEggSmash -> gameController.resetEggGame()
            Screen.GameTreasureChest -> gameController.resetChestGame()
            Screen.GameRedEnvelope -> gameController.resetEnvelopeGame()
            else -> {}
        }
        _uiState.update { it.copy(currentScreen = screen) }
    }

    fun goBack() {
        _uiState.update { current ->
            when (current.currentScreen) {
                is Screen.TabView -> current
                Screen.RitualStep1 -> current.copy(currentScreen = Screen.TabView(AppTab.HOME))
                Screen.RitualStep2 -> current.copy(currentScreen = Screen.RitualStep1)
                Screen.RitualStep3 -> current.copy(currentScreen = Screen.RitualStep2)
                Screen.GameEggSmash, Screen.GameTreasureChest, Screen.GameRedEnvelope ->
                    current.copy(currentScreen = Screen.RitualStep3)
                Screen.Reward -> current.copy(currentScreen = Screen.TabView(current.activeTab))
                Screen.LibrarySearch -> current.copy(currentScreen = Screen.TabView(AppTab.INVENTORY))
            }
        }
    }

    fun setStyle(style: String) {
        _uiState.update { it.copy(selectedStyle = style) }
    }

    fun setHumorLevel(level: Int) {
        _uiState.update { it.copy(humorLevel = level) }
    }

    fun setTopic(topic: String) {
        _uiState.update { it.copy(selectedTopic = topic) }
    }

    fun setRitual(ritual: RitualType) {
        _uiState.update { it.copy(selectedRitual = ritual) }
    }

    fun selectZodiac(zodiac: String) {
        gameController.selectEggZodiac(zodiac)
    }

    fun strikeEgg() {
        gameController.strikeEgg()
    }

    fun openTreasureChest() {
        gameController.openChest()
    }

    fun drawRedEnvelope(name: String = "Tài Lộc", value: String = "88,888 Xu") {
        gameController.touchPouch()
    }

    private suspend fun completeRitualAndAward(
        bonusCoins: Int = 888,
        bonusDiamonds: Int = 1,
        bonusJade: Int = 1,
        bonusEnvelopes: Int = 3
    ) {
        val topic = _uiState.value.selectedTopic
        val style = _uiState.value.selectedStyle
        val blessing = repository.getRandomBlessing(topic, style)

        // Award rewards
        repository.updateInventory { inv ->
            inv.copy(
                coins = inv.coins + bonusCoins,
                redEnvelopesCount = inv.redEnvelopesCount + bonusEnvelopes,
                diamondCount = inv.diamondCount + bonusDiamonds,
                jadeAmuletCount = inv.jadeAmuletCount + bonusJade
            )
        }

        // Save blessing into collection automatically
        repository.saveBlessingToCollection(blessing)

        _uiState.update {
            it.copy(
                currentBlessing = blessing,
                currentScreen = Screen.Reward
            )
        }
    }

    fun saveCurrentBlessing() {
        val blessing = _uiState.value.currentBlessing ?: return
        viewModelScope.launch {
            repository.saveBlessingToCollection(blessing)
            showToast("Đã lưu vào Kho Lời Chúc Cá Nhân thành công!")
        }
    }

    // Incubator Controls
    fun speedUpIncubator() {
        viewModelScope.launch {
            repository.updateInventory { inv ->
                val newTalismans = (inv.speedupTalismans - 1).coerceAtLeast(0)
                inv.copy(
                    speedupTalismans = newTalismans,
                    incubatorSecondsLeft = (inv.incubatorSecondsLeft - 3600).coerceAtLeast(10)
                )
            }
            _uiState.update {
                it.copy(
                    incubatorSeconds = (it.incubatorSeconds - 3600).coerceAtLeast(10),
                    incubatorCrack = (it.incubatorCrack + 10).coerceAtMost(99)
                )
            }
            showToast("⚡ Dùng Bùa Thần Tốc: Rút ngắn 1 giờ ấp!")
        }
    }

    fun waterIncubatorNectar() {
        viewModelScope.launch {
            repository.updateInventory { inv ->
                inv.copy(nectars = (inv.nectars - 1).coerceAtLeast(0))
            }
            _uiState.update {
                it.copy(incubatorCrack = (it.incubatorCrack + 5).coerceAtMost(99))
            }
            showToast("💧 Tưới Cam Lộ: Sinh lực rồng con tăng mạnh mẽ!")
        }
    }

    fun hammerAwakenIncubator() {
        _uiState.update {
            it.copy(incubatorCrack = (it.incubatorCrack + 10).coerceAtMost(99))
        }
        showToast("🔨 Búa Thần đánh thức: Vết nứt tỏa kim quang rực rỡ!")
    }

    // Pet Interactions
    fun interactPet(type: String) {
        val active = activeZodiacPet.value ?: return
        viewModelScope.launch {
            when (type) {
                "head" -> {
                    val updated = active.copy(
                        intimacy = (active.intimacy + 5).coerceAtMost(100),
                        happiness = (active.happiness + 5).coerceAtMost(100)
                    )
                    repository.updatePet(updated)
                    showToast("👆 Bảo Long thoải mái dụi đầu (+5 Thân thiết)!")
                }
                "peach" -> {
                    val updated = active.copy(
                        fullness = (active.fullness + 10).coerceAtMost(100),
                        happiness = (active.happiness + 10).coerceAtMost(100)
                    )
                    repository.updatePet(updated)
                    repository.updateInventory { it.copy(heavenlyPeaches = (it.heavenlyPeaches - 1).coerceAtLeast(0)) }
                    showToast("🍑 Nhai Đào Tiên giòn tan (+10 No nê & Vui vẻ)!")
                }
                "water" -> {
                    val updated = active.copy(
                        spiritualEnergy = (active.spiritualEnergy + 15).coerceAtMost(100),
                        intimacy = (active.intimacy + 5).coerceAtMost(100)
                    )
                    repository.updatePet(updated)
                    showToast("🌊 Nước suối gột rửa vảy rồng sáng ngời (+15 Linh lực)!")
                }
            }
        }
    }

    fun harvestPetReward() {
        viewModelScope.launch {
            repository.updateInventory { inv ->
                inv.copy(
                    coins = inv.coins + 200,
                    redEnvelopesCount = inv.redEnvelopesCount + 1
                )
            }
            showToast("🎉 Đã thu hoạch +200 Xu & 1 Lì Xì Đỏ từ Linh Thú!")
        }
    }

    // Quick Item Use from Inventory
    fun quickUseItem(itemName: String) {
        viewModelScope.launch {
            when (itemName) {
                "hammer" -> {
                    setRitual(RitualType.EGG_SMASH)
                    navigateToScreen(Screen.GameEggSmash)
                }
                "nectar" -> waterIncubatorNectar()
                "speedup" -> speedUpIncubator()
                "peach" -> interactPet("peach")
                else -> showToast("✨ Đã kích hoạt pháp bảo linh ứng!")
            }
        }
    }

    // Library query
    fun searchLibrary(query: String? = null, topic: String? = null, style: String? = null) {
        val q = query ?: _uiState.value.librarySearchQuery
        val t = topic ?: _uiState.value.libraryFilterTopic
        val s = style ?: _uiState.value.libraryFilterStyle

        _uiState.update {
            it.copy(
                librarySearchQuery = q,
                libraryFilterTopic = t,
                libraryFilterStyle = s,
                isLibraryLoading = true
            )
        }

        viewModelScope.launch {
            val results = repository.queryBlessings(t, s, q, limit = 50)
            _uiState.update {
                it.copy(
                    libraryResults = results,
                    isLibraryLoading = false
                )
            }
        }
    }

    fun showToast(message: String) {
        _uiState.update { it.copy(toastMessage = message) }
        viewModelScope.launch {
            delay(2200)
            _uiState.update { if (it.toastMessage == message) it.copy(toastMessage = null) else it }
        }
    }

    fun clearToast() {
        _uiState.update { it.copy(toastMessage = null) }
    }
}
