package com.example.ui.game

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldLight

@Composable
fun CoinRainOverlay(
    particles: List<RainParticleItem>,
    modifier: Modifier = Modifier
) {
    if (particles.isEmpty()) return

    Box(modifier = modifier.fillMaxSize()) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val canvasWidth = size.width
            val canvasHeight = size.height

            particles.forEach { p ->
                val px = p.xRatio * canvasWidth
                val py = p.yRatio * canvasHeight
                val pSize = p.sizeDp * density

                rotate(degrees = p.rotation, pivot = Offset(px, py)) {
                    when (p.particleType) {
                        ParticleType.GOLD_COIN -> drawGoldCoin(px, py, pSize)
                        ParticleType.GOLD_SYCEE -> drawSyceeIngot(px, py, pSize)
                        ParticleType.RED_ENVELOPE -> drawMiniRedEnvelope(px, py, pSize)
                        ParticleType.SPARKLE -> drawSparkle(px, py, pSize)
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawGoldCoin(x: Float, y: Float, diameter: Float) {
    val radius = diameter / 2f
    // Outer golden disc
    drawCircle(
        color = ImperialGold,
        radius = radius,
        center = Offset(x, y)
    )
    // Inner rim
    drawCircle(
        color = ImperialGoldLight,
        radius = radius * 0.8f,
        center = Offset(x, y)
    )
    // Traditional oriental square hole in center
    val holeHalf = radius * 0.35f
    drawRect(
        color = Color(0xFF6B4E00),
        topLeft = Offset(x - holeHalf, y - holeHalf),
        size = Size(holeHalf * 2, holeHalf * 2)
    )
}

private fun DrawScope.drawSyceeIngot(x: Float, y: Float, size: Float) {
    val path = Path().apply {
        moveTo(x - size * 0.5f, y - size * 0.2f)
        cubicTo(
            x - size * 0.25f, y - size * 0.45f,
            x + size * 0.25f, y - size * 0.45f,
            x + size * 0.5f, y - size * 0.2f
        )
        cubicTo(
            x + size * 0.4f, y + size * 0.3f,
            x - size * 0.4f, y + size * 0.3f,
            x - size * 0.5f, y - size * 0.2f
        )
        close()
    }
    drawPath(path = path, color = ImperialGold)
    // Inner golden crest
    drawCircle(
        color = ImperialGoldLight,
        radius = size * 0.18f,
        center = Offset(x, y - size * 0.08f)
    )
}

private fun DrawScope.drawMiniRedEnvelope(x: Float, y: Float, size: Float) {
    val width = size * 0.8f
    val height = size * 1.2f
    val left = x - width / 2
    val top = y - height / 2

    // Red envelope body
    drawRoundRect(
        color = CinnabarRed,
        topLeft = Offset(left, top),
        size = Size(width, height),
        cornerRadius = CornerRadius(width * 0.15f, width * 0.15f)
    )
    // Golden flap & seal
    drawCircle(
        color = ImperialGold,
        radius = width * 0.25f,
        center = Offset(x, top + height * 0.38f)
    )
    drawCircle(
        color = ImperialGoldLight,
        radius = width * 0.15f,
        center = Offset(x, top + height * 0.38f)
    )
}

private fun DrawScope.drawSparkle(x: Float, y: Float, size: Float) {
    val half = size / 2
    val path = Path().apply {
        moveTo(x, y - half)
        quadraticTo(x, y, x + half, y)
        quadraticTo(x, y, x, y + half)
        quadraticTo(x, y, x - half, y)
        quadraticTo(x, y, x, y - half)
        close()
    }
    drawPath(path = path, color = ImperialGoldLight)
}
