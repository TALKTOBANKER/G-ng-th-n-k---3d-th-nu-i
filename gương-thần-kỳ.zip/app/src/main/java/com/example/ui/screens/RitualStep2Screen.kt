package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Cake
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Cottage
import androidx.compose.material.icons.filled.Diversity1
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.LensBlur
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.MoodBad
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Park
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.SportsBar
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CinnabarDeep
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.EmeraldJade
import com.example.ui.theme.EmeraldJadeDark
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldDark
import com.example.ui.theme.ImperialGoldLight
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.MidnightSurfaceHigh
import com.example.ui.theme.MidnightSurfaceLowest
import com.example.ui.theme.OnSurfaceText
import com.example.ui.theme.OnSurfaceVariantText

data class TopicItem(
    val key: String,
    val name: String,
    val subtitle: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color
)

@Composable
fun RitualStep2Screen(
    selectedTopic: String,
    onTopicSelected: (String) -> Unit,
    onNextStep: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBackground)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 90.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // PROGRESS HEADER
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = ImperialGold,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "TIẾN TRÌNH THỈNH QUẺ",
                    color = ImperialGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Text(
                text = "Bước 2 / 3",
                color = ImperialGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.Black
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Progress Bar (66.6%)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(MidnightSurfaceLowest)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.66f)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        Brush.horizontalGradient(listOf(ImperialGold, ImperialGoldLight))
                    )
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Cosmic Oracle Guidance Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MidnightSurfaceHigh)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.verticalGradient(listOf(ImperialGold, ImperialGoldDark))
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.LensBlur,
                    contentDescription = null,
                    tint = Color(0xFF422D00),
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "THÔNG ĐIỆP LINH KHÍ",
                    color = ImperialGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Text(
                    text = "Gương Thần sẽ kết nối năng lượng vũ trụ theo chủ đề linh ứng bạn chọn.",
                    color = OnSurfaceText,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // GROUP 1: ĐỜI SỐNG & GIA ĐÌNH (4 Topics)
        val group1 = listOf(
            TopicItem("cong_danh", "Công Danh", "Thăng tiến vù vù", Icons.Default.MilitaryTech, ImperialGold),
            TopicItem("tai_loc", "Tài Lộc Vô Biên", "Đại cát đại lợi", Icons.Default.Savings, ImperialGoldLight),
            TopicItem("tinh_duyen", "Tình Duyên", "Tơ hồng cập bến", Icons.Default.Favorite, CinnabarRed),
            TopicItem("gia_dao", "Gia Đạo An Khang", "Trường thọ bình an", Icons.Default.Spa, EmeraldJade)
        )
        TopicGroupSection(
            groupTitle = "Đời Sống & Gia Đình",
            groupIcon = Icons.Default.Cottage,
            badge = "4 Quẻ",
            topics = group1,
            selectedKey = selectedTopic,
            onSelect = onTopicSelected
        )

        Spacer(modifier = Modifier.height(20.dp))

        // GROUP 2: VUI VẺ & GIAO TIẾP (4 Topics)
        val group2 = listOf(
            TopicItem("dip_nhau", "Dịp Nhậu Tụ Tập", "Ly nâng hết nấc", Icons.Default.SportsBar, ImperialGold),
            TopicItem("ban_be", "Hội Bạn Tri Kỷ", "Kề vai sát cánh", Icons.Default.Diversity1, EmeraldJade),
            TopicItem("sinh_nhat", "Sinh Nhật Bùng Nổ", "Tuổi mới rực rỡ", Icons.Default.Cake, CinnabarRed),
            TopicItem("du_lich", "Vi Vu Du Lịch", "Vạn dặm bình an", Icons.Default.FlightTakeoff, Color(0xFF38BDF8))
        )
        TopicGroupSection(
            groupTitle = "Vui Vẻ & Giao Tiếp",
            groupIcon = Icons.Default.Celebration,
            badge = "4 Quẻ",
            topics = group2,
            selectedKey = selectedTopic,
            onSelect = onTopicSelected
        )

        Spacer(modifier = Modifier.height(20.dp))

        // GROUP 3: ĐẶC BIỆT & TÂM LINH (4 Topics)
        val group3 = listOf(
            TopicItem("chuc_tho", "Chúc Thọ Cha Mẹ", "Bách niên giai lão", Icons.Default.Park, EmeraldJade),
            TopicItem("chuc_chau", "Chúc Cháu Mau Lớn", "Ngoan ngoãn giỏi giang", Icons.Default.AutoAwesome, ImperialGoldLight),
            TopicItem("tam_linh", "Cầu Khấn Giải Hạn", "Hóa giải tai ách", Icons.Default.NotificationsActive, ImperialGold),
            TopicItem("chua_lanh", "Chữa Lành Tâm Hồn", "Giọt ngọc tĩnh tâm, vạn sự tùy duyên", Icons.Default.SelfImprovement, EmeraldJadeDark)
        )
        TopicGroupSection(
            groupTitle = "Đặc Biệt & Tâm Linh",
            groupIcon = Icons.Default.LocalFireDepartment,
            badge = "4 Quẻ",
            topics = group3,
            selectedKey = selectedTopic,
            onSelect = onTopicSelected
        )

        Spacer(modifier = Modifier.height(16.dp))
        }

        // FLOATING DOCKED CONTINUE BUTTON: TIẾP TỤC KHUI QUẺ >
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, MidnightBackground.copy(alpha = 0.95f), MidnightBackground)
                    )
                )
                .padding(16.dp)
        ) {
            Button(
                onClick = onNextStep,
                modifier = Modifier
                    .testTag("btn_step2_next")
                    .fillMaxWidth()
                    .height(60.dp)
                    .shadow(12.dp, RoundedCornerShape(30.dp)),
                shape = RoundedCornerShape(30.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(listOf(Color(0xFFF43648), Color(0xFFB21222)))
                        )
                        .border(1.5.dp, ImperialGoldLight, RoundedCornerShape(30.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "TIẾP TỤC KHUI QUẺ",
                            color = ImperialGoldLight,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(
                            imageVector = Icons.Default.ChevronRight,
                            contentDescription = null,
                            tint = ImperialGoldLight,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TopicGroupSection(
    groupTitle: String,
    groupIcon: androidx.compose.ui.graphics.vector.ImageVector,
    badge: String,
    topics: List<TopicItem>,
    selectedKey: String,
    onSelect: (String) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(ImperialGoldDark),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = groupIcon,
                        contentDescription = null,
                        tint = Color(0xFF271900),
                        modifier = Modifier.size(16.dp)
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = groupTitle.uppercase(),
                    color = ImperialGoldLight,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(MidnightSurfaceHigh)
                    .padding(horizontal = 8.dp, vertical = 2.dp)
            ) {
                Text(
                    text = badge,
                    color = OnSurfaceVariantText,
                    fontSize = 10.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // 2-column Grid for cards
        val pairs = topics.chunked(2)
        pairs.forEach { pair ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                pair.forEach { item ->
                    val isSelected = item.key == selectedKey
                    Box(modifier = Modifier.weight(1f)) {
                        TopicCardItem(
                            item = item,
                            isSelected = isSelected,
                            onClick = { onSelect(item.key) },
                            modifier = Modifier.testTag("topic_${item.key}")
                        )
                    }
                }
                if (pair.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}

@Composable
fun TopicCardItem(
    item: TopicItem,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(
                if (isSelected) MidnightSurfaceHigh else MidnightSurface
            )
            .border(
                width = if (isSelected) 1.5.dp else 1.dp,
                color = if (isSelected) ImperialGold else Color(0xFF3B304A),
                shape = RoundedCornerShape(14.dp)
            )
            .clickable { onClick() }
            .padding(12.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Check top-right
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End
            ) {
                Box(
                    modifier = Modifier
                        .size(20.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) ImperialGold else MidnightSurfaceLowest),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color.Black,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }

            // Circle icon
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(MidnightSurfaceLowest)
                    .border(1.dp, item.color, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = item.icon,
                    contentDescription = null,
                    tint = item.color,
                    modifier = Modifier.size(26.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = item.name,
                color = if (isSelected) ImperialGold else OnSurfaceText,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            Text(
                text = item.subtitle,
                color = OnSurfaceVariantText,
                fontSize = 10.sp,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}
