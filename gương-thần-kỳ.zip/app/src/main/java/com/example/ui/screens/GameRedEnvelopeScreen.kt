package com.example.ui.screens

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.scaleIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HourglassTop
import androidx.compose.material.icons.filled.MarkEmailUnread
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.game.CoinRainOverlay
import com.example.ui.game.LuckyEnvelopeItem
import com.example.ui.game.RedEnvelopeGameState
import com.example.ui.theme.CinnabarDeep
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.CinnabarRedDark
import com.example.ui.theme.EmeraldJade
import com.example.ui.theme.EmeraldJadeDark
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldDark
import com.example.ui.theme.ImperialGoldLight
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.MidnightSurfaceHigh
import com.example.ui.theme.MidnightSurfaceLow
import com.example.ui.theme.MidnightSurfaceLowest
import com.example.ui.theme.OnSurfaceText
import com.example.ui.theme.OnSurfaceVariantText
import kotlin.math.sqrt

@Composable
fun GameRedEnvelopeScreen(
    state: RedEnvelopeGameState,
    dailyDrawsLeft: Int,
    coins: Int,
    onDrawEnvelope: (LuckyEnvelopeItem) -> Unit,
    onTouchPouch: () -> Unit,
    onShakeGesture: () -> Unit,
    onAccelerometerReading: (Float) -> Unit,
    onReset: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val pouchAngle = remember { Animatable(0f) }
    val pouchScale = remember { Animatable(1f) }

    // Accelerometer shake detection
    DisposableEffect(Unit) {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val accelerometer = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event == null) return
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                val gForce = (sqrt((x * x + y * y + z * z).toDouble()) / SensorManager.GRAVITY_EARTH).toFloat()
                onAccelerometerReading(gForce)
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }

        sensorManager?.registerListener(listener, accelerometer, SensorManager.SENSOR_DELAY_UI)
        onDispose {
            sensorManager?.unregisterListener(listener)
        }
    }

    // Animate pouch when shaken or coin rain active
    LaunchedEffect(state.isCoinRainActive) {
        if (state.isCoinRainActive) {
            pouchAngle.animateTo(12f, tween(70))
            pouchScale.animateTo(1.1f, tween(70))
            pouchAngle.animateTo(-12f, tween(80))
            pouchAngle.animateTo(8f, tween(70))
            pouchAngle.animateTo(0f, tween(70))
            pouchScale.animateTo(1f, tween(70))
        }
    }

    val infiniteTransition = rememberInfiniteTransition(label = "pulsePouch")
    val pulseGlow by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(1300), RepeatMode.Reverse),
        label = "pulseGlow"
    )

    Box(modifier = modifier.fillMaxSize()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MidnightBackground)
                .verticalScroll(scrollState)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // TOP BANNER
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MidnightSurfaceHigh)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Stars,
                        contentDescription = null,
                        tint = ImperialGold,
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "RÚT BAO LÌ XÌ MAY MẮN",
                        color = ImperialGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onReset,
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(MidnightSurfaceLow)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Làm mới",
                            tint = ImperialGold,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(ImperialGoldDark)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Đóng",
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // CENTERPIECE: BROCADE POUCH & FLOATING RED ENVELOPES
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(300.dp),
                contentAlignment = Alignment.Center
            ) {
                // Interactive Floating Envelopes
                if (!state.isDrawn) {
                    // Envelope 1: Đại Cát (Top Left)
                    state.envelopes.getOrNull(0)?.let { env ->
                        FloatingEnvelopeCard(
                            item = env,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .offset(x = 10.dp, y = 6.dp)
                                .rotate(-14f),
                            onClick = { onDrawEnvelope(env) }
                        )
                    }

                    // Envelope 2: Như Ý (Top Right)
                    state.envelopes.getOrNull(1)?.let { env ->
                        FloatingEnvelopeCard(
                            item = env,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .offset(x = (-10).dp, y = 6.dp)
                                .rotate(14f),
                            onClick = { onDrawEnvelope(env) }
                        )
                    }

                    // Envelope 3: Phú Quý (Bottom Left)
                    state.envelopes.getOrNull(2)?.let { env ->
                        FloatingEnvelopeCard(
                            item = env,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .offset(x = 10.dp, y = (-10).dp)
                                .rotate(-8f),
                            onClick = { onDrawEnvelope(env) }
                        )
                    }

                    // Envelope 4: Tài Lộc (Bottom Right)
                    state.envelopes.getOrNull(3)?.let { env ->
                        FloatingEnvelopeCard(
                            item = env,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .offset(x = (-10).dp, y = (-10).dp)
                                .rotate(8f),
                            onClick = { onDrawEnvelope(env) }
                        )
                    }

                    // Central Imperial Brocade Pouch
                    Box(
                        modifier = Modifier
                            .size(175.dp)
                            .scale(pouchScale.value * pulseGlow)
                            .rotate(pouchAngle.value)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    listOf(CinnabarRed, CinnabarRedDark, MidnightSurfaceLowest)
                                )
                            )
                            .border(3.dp, ImperialGold, CircleShape)
                            .clickable { onTouchPouch() },
                        contentAlignment = Alignment.Center
                    ) {
                        // Golden Seal "PHÚC" (福)
                        Box(
                            modifier = Modifier
                                .size(96.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(ImperialGoldLight, ImperialGold, ImperialGoldDark)
                                    )
                                )
                                .padding(4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                                    .background(CinnabarRedDark),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = "福",
                                        color = ImperialGold,
                                        fontSize = 40.sp,
                                        fontWeight = FontWeight.Black,
                                        lineHeight = 42.sp
                                    )
                                    Text(
                                        text = "PHÚC KHÍ",
                                        color = ImperialGoldLight,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        letterSpacing = 1.sp
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // DRAWN ENVELOPE REVEAL CARD
                    state.selectedEnvelope?.let { env ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier
                                .size(240.dp, 280.dp)
                                .clip(RoundedCornerShape(24.dp))
                                .background(
                                    Brush.verticalGradient(listOf(CinnabarRed, CinnabarDeep))
                                )
                                .border(2.5.dp, ImperialGold, RoundedCornerShape(24.dp))
                                .padding(16.dp)
                        ) {
                            Text(
                                text = env.chineseChar,
                                color = ImperialGold,
                                fontSize = 54.sp,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = env.name.uppercase(),
                                color = ImperialGoldLight,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = env.blessingTag,
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(MidnightSurfaceLowest.copy(alpha = 0.8f))
                                    .padding(horizontal = 14.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.MonetizationOn,
                                    contentDescription = null,
                                    tint = ImperialGold,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "+${env.displayValue}",
                                    color = ImperialGold,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // STATUS MESSAGE
            Text(
                text = state.statusMessage,
                color = ImperialGoldLight,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // SHAKE SENSOR & ACCELEROMETER STATUS ROW
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MidnightSurfaceHigh)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(EmeraldJade)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "CẢM BIẾN LẮC TAY (G-FORCE: ${String.format("%.1f", state.lastShakeGForce.coerceAtLeast(1.0f))})",
                        color = EmeraldJade,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                // Shake intensity meter
                Box(
                    modifier = Modifier
                        .width(60.dp)
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(MidnightSurfaceLowest)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(state.shakeIntensity.coerceIn(0.1f, 1f))
                            .fillMaxSize()
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                Brush.horizontalGradient(listOf(EmeraldJade, ImperialGold, CinnabarRed))
                            )
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ACTION BUTTON 1: LẮC ĐIỆN THOẠI (SIMULATE / TEST SHAKE)
            Button(
                onClick = onShakeGesture,
                enabled = !state.isDrawn,
                modifier = Modifier
                    .testTag("btn_shake_phone")
                    .fillMaxWidth()
                    .height(52.dp)
                    .shadow(10.dp, RoundedCornerShape(26.dp)),
                shape = RoundedCornerShape(26.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                listOf(EmeraldJadeDark, EmeraldJade, ImperialGoldDark)
                            )
                        )
                        .border(1.5.dp, ImperialGoldLight, RoundedCornerShape(26.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Vibration,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "LẮC ĐIỆN THOẠI • MƯA TIỀN VÀNG",
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // ACTION BUTTON 2: CHẠM RÚT LÌ XÌ
            Button(
                onClick = onTouchPouch,
                enabled = !state.isDrawn,
                modifier = Modifier
                    .testTag("btn_draw_envelope")
                    .fillMaxWidth()
                    .height(56.dp)
                    .shadow(12.dp, RoundedCornerShape(28.dp)),
                shape = RoundedCornerShape(28.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(listOf(CinnabarRed, CinnabarDeep))
                        )
                        .border(1.5.dp, ImperialGoldLight, RoundedCornerShape(28.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MarkEmailUnread,
                            contentDescription = null,
                            tint = ImperialGold,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (state.isDrawn) "ĐÃ RÚT LÌ XÌ MAY MẮN!"
                            else "CHẠM RÚT LÌ XÌ NGAY",
                            color = ImperialGold,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        // CƠN MƯA TIỀN VÀNG & LÌ XÌ MAY MẮN OVERLAY
        CoinRainOverlay(particles = state.rainParticles)
    }
}

@Composable
private fun FloatingEnvelopeCard(
    item: LuckyEnvelopeItem,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .testTag("envelope_${item.id}")
            .size(76.dp, 100.dp)
            .shadow(10.dp, RoundedCornerShape(12.dp))
            .clip(RoundedCornerShape(12.dp))
            .background(Brush.verticalGradient(listOf(CinnabarRed, CinnabarDeep)))
            .border(1.5.dp, ImperialGold, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = item.chineseChar,
            color = ImperialGold,
            fontSize = 26.sp,
            fontWeight = FontWeight.Black,
            lineHeight = 28.sp
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = item.name,
                color = ImperialGoldLight,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = item.displayValue,
                color = Color.White,
                fontSize = 8.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
