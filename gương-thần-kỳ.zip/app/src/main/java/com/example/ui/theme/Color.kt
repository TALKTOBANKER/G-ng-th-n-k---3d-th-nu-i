package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Imperial & Celestial Vietnamese Festive Theme Palette
val ImperialGold = Color(0xFFFDBB2D)
val ImperialGoldLight = Color(0xFFFFDEA8)
val ImperialGoldDark = Color(0xFFDB9D00)
val GoldContainer = Color(0xFF5E4200)

val CinnabarRed = Color(0xFFD91E2E)
val CinnabarRedLight = Color(0xFFFFB3AE)
val CinnabarRedDark = Color(0xFF68000C)
val CinnabarDeep = Color(0xFF410005)

val EmeraldJade = Color(0xFF76D9B2)
val EmeraldJadeLight = Color(0xFF92F6CD)
val EmeraldJadeDark = Color(0xFF007F5E)
val EmeraldJadeDeep = Color(0xFF002116)

val MidnightBackground = Color(0xFF180E26)
val MidnightSurface = Color(0xFF251B33)
val MidnightSurfaceLowest = Color(0xFF130921)
val MidnightSurfaceLow = Color(0xFF21172F)
val MidnightSurfaceHigh = Color(0xFF30253E)
val MidnightSurfaceHighest = Color(0xFF3B304A)
val MidnightSurfaceBright = Color(0xFF3F344E)

val OnSurfaceText = Color(0xFFEDDCFE)
val OnSurfaceVariantText = Color(0xFFE6BDBA)
val OutlineBorder = Color(0xFFAC8885)
val OutlineVariant = Color(0xFF5C3F3E)

val ScrollParchmentLight = Color(0xFFFDE8BB)
val ScrollParchmentMid = Color(0xFFF7D58B)
val ScrollParchmentDark = Color(0xFFEED081)
val ScrollText = Color(0xFF422D00)
