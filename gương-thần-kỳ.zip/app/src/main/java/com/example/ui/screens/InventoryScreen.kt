package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Backpack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.FilterVintage
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Hardware
import androidx.compose.material.icons.filled.HistoryEdu
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Sanitizer
import androidx.compose.material.icons.filled.Savings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.SavedBlessingEntity
import com.example.data.local.UserInventoryEntity
import com.example.ui.theme.CinnabarDeep
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.CinnabarRedLight
import com.example.ui.theme.EmeraldJade
import com.example.ui.theme.EmeraldJadeDark
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldDark
import com.example.ui.theme.ImperialGoldLight
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.MidnightSurfaceHigh
import com.example.ui.theme.MidnightSurfaceLow
import com.example.ui.theme.MidnightSurfaceLowest
import com.example.ui.theme.OnSurfaceText
import com.example.ui.theme.OnSurfaceVariantText

private const val IMG_CARP_BANNER =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuDNaXVA0UGz2p0OvFrjyzhV1SxYPwWEGkamEAPUc8vT6RAZOxN2DOusmtxbNYiWd5Rr7YX8DFitijqOuN1b_R1yk7_oDVQZqhwiiXGnuF83tunoeF6qSQpnkH58zeLA3gsfGuVnDZjG0Vn9WUTftgQ2s2hjukW_EyMb6PNgySAdaP3inXAF237w58EUVrVFq6ffCbGDQ57hXrpfhllLWd0x4rqZWJ7-iwtZLwGPUxPRmar0ru4ogals3g"

@Composable
fun InventoryScreen(
    inventory: UserInventoryEntity?,
    savedBlessings: List<SavedBlessingEntity>,
    onUseItem: (itemName: String) -> Unit,
    onSummonBlessing: () -> Unit,
    onQuickUse: () -> Unit,
    onOpenLibrary: () -> Unit,
    onToast: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()
    var selectedSection by remember { mutableIntStateOf(0) } // 0: Blessings, 1: Artifacts

    val coins = inventory?.coins ?: 8888
    val luck = inventory?.luckPercent ?: 99
    val hammers = inventory?.goldHammers ?: 12
    val nectars = inventory?.nectars ?: 5
    val speedups = inventory?.speedupTalismans ?: 8
    val peaches = inventory?.heavenlyPeaches ?: 24

    fun copyBlessing(blessing: SavedBlessingEntity) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val full = "${blessing.title}\n${blessing.content}\n${blessing.rhyme}"
        clipboard?.setPrimaryClip(ClipData.newPlainText("Lời chúc", full))
        onToast("Đã sao chép lời chúc linh ứng!")
    }

    fun shareBlessing(blessing: SavedBlessingEntity) {
        val full = "${blessing.title}\n${blessing.content}\n${blessing.rhyme}"
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, full)
        }
        context.startActivity(Intent.createChooser(intent, "Chia sẻ lời chúc Tết"))
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // AURA & AMBIENT GLOW STATUS PANEL
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(MidnightSurfaceHigh)
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(MidnightSurfaceLowest),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stars,
                            contentDescription = null,
                            tint = ImperialGold,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = String.format("%,d", coins),
                                color = ImperialGold,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "XU PHÚC",
                                color = OnSurfaceVariantText,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.VolunteerActivism,
                                contentDescription = null,
                                tint = EmeraldJade,
                                modifier = Modifier.size(13.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "Tích tụ phúc khí linh thiêng",
                                color = EmeraldJade,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MidnightSurfaceLowest)
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(ImperialGold)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "$luck%",
                            color = ImperialGold,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Text(
                            text = "Khí Vận",
                            color = OnSurfaceVariantText,
                            fontSize = 10.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Cực Phẩm Vận Đỏ",
                        color = ImperialGoldLight,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Progress bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(MidnightSurfaceLowest)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(luck / 100f)
                        .fillMaxSize()
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(ImperialGold, CinnabarRed, ImperialGoldLight)
                            )
                        )
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 3D SEGMENTED CONTROL TABS: Kho Lời Chúc (12) vs Túi Pháp Bảo (8)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MidnightSurfaceLowest)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val isBlessingsActive = selectedSection == 0
            Box(
                modifier = Modifier
                    .testTag("tab_switch_blessings")
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isBlessingsActive) Brush.verticalGradient(
                            listOf(CinnabarRed, CinnabarDeep)
                        ) else Brush.verticalGradient(listOf(MidnightSurface, MidnightSurface))
                    )
                    .clickable { selectedSection = 0 },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.HistoryEdu,
                        contentDescription = null,
                        tint = if (isBlessingsActive) Color.White else OnSurfaceVariantText,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Kho Lời Chúc (${savedBlessings.size})",
                        color = if (isBlessingsActive) Color.White else OnSurfaceVariantText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            val isArtifactsActive = selectedSection == 1
            Box(
                modifier = Modifier
                    .testTag("tab_switch_artifacts")
                    .weight(1f)
                    .height(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (isArtifactsActive) Brush.verticalGradient(
                            listOf(EmeraldJadeDark, Color(0xFF003828))
                        ) else Brush.verticalGradient(listOf(MidnightSurface, MidnightSurface))
                    )
                    .clickable { selectedSection = 1 },
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Backpack,
                        contentDescription = null,
                        tint = if (isArtifactsActive) Color.White else OnSurfaceVariantText,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Túi Pháp Bảo (8)",
                        color = if (isArtifactsActive) Color.White else OnSurfaceVariantText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // SECTION CONTENT (Based on selected tab)
        if (selectedSection == 0) {
            // BLESSINGS SECTION
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoStories,
                        contentDescription = null,
                        tint = ImperialGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Quẻ May Mắn Đã Khai",
                        color = OnSurfaceText,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(MidnightSurfaceHigh)
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.FilterVintage,
                        contentDescription = null,
                        tint = ImperialGold,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(3.dp))
                    Text(
                        text = "Xuân Giáp Thìn",
                        color = ImperialGold,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (savedBlessings.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MidnightSurface)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.HistoryEdu,
                            contentDescription = null,
                            tint = ImperialGold,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Chưa có lời chúc nào trong kho!",
                            color = OnSurfaceText,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Hãy bắt đầu khui quẻ may mắn hoặc duyệt kho 7.200 câu chúc.",
                            color = OnSurfaceVariantText,
                            fontSize = 11.sp,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
            } else {
                savedBlessings.forEach { blessing ->
                    SavedBlessingCard(
                        blessing = blessing,
                        onCopy = { copyBlessing(blessing) },
                        onShare = { shareBlessing(blessing) }
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
            }
        } else {
            // ARTIFACTS INVENTORY SECTION (4-Cell 3D Grid)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Category,
                        contentDescription = null,
                        tint = ImperialGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Pháp Bảo Trợ Linh",
                        color = OnSurfaceText,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "4 / 16 Túi Pháp Viện",
                    color = OnSurfaceVariantText,
                    fontSize = 11.sp
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ArtifactGridItem(
                    name = "Búa Hoàng Kim",
                    desc = "Khai mở trứng rồng",
                    count = "x$hammers",
                    icon = Icons.Default.Hardware,
                    iconBg = Brush.verticalGradient(listOf(ImperialGoldLight, ImperialGoldDark)),
                    iconTint = Color(0xFF422D00),
                    btnTint = ImperialGold,
                    onUse = { onUseItem("hammer") },
                    modifier = Modifier.weight(1f)
                )

                ArtifactGridItem(
                    name = "Cam Lộ Bồ Đề",
                    desc = "Nuôi dưỡng linh thú",
                    count = "x$nectars",
                    icon = Icons.Default.Sanitizer,
                    iconBg = Brush.verticalGradient(listOf(EmeraldJade, EmeraldJadeDark)),
                    iconTint = Color.White,
                    btnTint = EmeraldJade,
                    onUse = { onUseItem("nectar") },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ArtifactGridItem(
                    name = "Bùa Thần Tốc 1H",
                    desc = "Rút ngắn ấp nở",
                    count = "x$speedups",
                    icon = Icons.Default.Bolt,
                    iconBg = Brush.verticalGradient(listOf(CinnabarRedLight, CinnabarRed)),
                    iconTint = Color.White,
                    btnTint = CinnabarRed,
                    onUse = { onUseItem("speedup") },
                    modifier = Modifier.weight(1f)
                )

                ArtifactGridItem(
                    name = "Đào Tiên Lương",
                    desc = "Thăng cấp thần thú",
                    count = "x$peaches",
                    icon = Icons.Default.Spa,
                    iconBg = Brush.verticalGradient(listOf(ImperialGoldLight, CinnabarRed)),
                    iconTint = Color.White,
                    btnTint = ImperialGold,
                    onUse = { onUseItem("peach") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // SACRED CARP BANNER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MidnightSurfaceLow)
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(60.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MidnightSurfaceLowest)
            ) {
                AsyncImage(
                    model = IMG_CARP_BANNER,
                    contentDescription = "Hương Vân Chiêu Tài",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = "HƯƠNG VÂN CHIÊU TÀI",
                    color = ImperialGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Thỉnh đủ 18 quẻ cát để mở khóa danh hiệu “Kim Giác Đại Tiên” cùng 1,888 Xu thưởng.",
                    color = OnSurfaceVariantText,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // DUAL ACTION BUTTONS
        Button(
            onClick = onSummonBlessing,
            modifier = Modifier
                .testTag("btn_summon_blessing")
                .fillMaxWidth()
                .height(52.dp)
                .shadow(8.dp, RoundedCornerShape(26.dp)),
            shape = RoundedCornerShape(26.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(listOf(CinnabarRed, CinnabarDeep))
                    )
                    .border(1.dp, ImperialGoldLight, RoundedCornerShape(26.dp)),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = ImperialGold,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "🎋 THỈNH THÊM LỜI CHÚC MỚI",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = onQuickUse,
            modifier = Modifier
                .testTag("btn_quick_use")
                .fillMaxWidth()
                .height(48.dp)
                .shadow(6.dp, RoundedCornerShape(24.dp)),
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(listOf(EmeraldJadeDark, Color(0xFF003828)))
                    )
                    .border(1.dp, EmeraldJade.copy(alpha = 0.5f), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FlashOn,
                        contentDescription = null,
                        tint = ImperialGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "✨ DÙNG NHANH VẬT PHẨM",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // BROWSE 7,200 WISHES LIBRARY BUTTON
        Button(
            onClick = onOpenLibrary,
            modifier = Modifier
                .testTag("btn_open_library")
                .fillMaxWidth()
                .height(48.dp)
                .shadow(6.dp, RoundedCornerShape(24.dp)),
            shape = RoundedCornerShape(24.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(listOf(ImperialGoldDark, Color(0xFF5E4200)))
                    )
                    .border(1.dp, ImperialGoldLight, RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.MenuBook,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "📚 TRA CỨU KHO 7.200 CÂU CHÚC",
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun SavedBlessingCard(
    blessing: SavedBlessingEntity,
    onCopy: () -> Unit,
    onShare: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MidnightSurface)
            .border(1.dp, Color(0xFF3B304A), RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(ImperialGoldDark)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = blessing.omen,
                            color = Color.Black,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = blessing.topicName,
                        color = OnSurfaceVariantText,
                        fontSize = 11.sp
                    )
                }
                Icon(
                    imageVector = Icons.Default.Verified,
                    contentDescription = null,
                    tint = ImperialGold,
                    modifier = Modifier.size(16.dp)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MidnightSurfaceLowest)
                    .padding(10.dp)
            ) {
                Column {
                    Text(
                        text = "“${blessing.title}”",
                        color = ImperialGoldLight,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = blessing.content,
                        color = OnSurfaceVariantText,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(MidnightSurfaceHigh)
                        .clickable { onCopy() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ContentCopy,
                            contentDescription = null,
                            tint = EmeraldJade,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Sao chép", color = OnSurfaceText, fontSize = 10.sp)
                    }
                }

                Spacer(modifier = Modifier.width(6.dp))

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(ImperialGoldDark)
                        .clickable { onShare() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Share,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Gửi Lì Xì", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun ArtifactGridItem(
    name: String,
    desc: String,
    count: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Brush,
    iconTint: Color,
    btnTint: Color,
    onUse: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(MidnightSurface)
            .border(1.dp, Color(0xFF3B304A), RoundedCornerShape(16.dp))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(MidnightSurfaceLowest)
                    .padding(horizontal = 6.dp, vertical = 1.dp)
            ) {
                Text(
                    text = count,
                    color = ImperialGold,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(iconBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = name,
                tint = iconTint,
                modifier = Modifier.size(28.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = name,
            color = OnSurfaceText,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
        Text(
            text = desc,
            color = OnSurfaceVariantText,
            fontSize = 9.sp,
            maxLines = 1
        )

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = onUse,
            modifier = Modifier
                .fillMaxWidth()
                .height(32.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MidnightSurfaceHigh)
        ) {
            Text(
                text = "SỬ DỤNG",
                color = btnTint,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
