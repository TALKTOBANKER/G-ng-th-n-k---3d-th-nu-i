package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Flare
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.CinnabarDeep
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.EmeraldJade
import com.example.ui.theme.EmeraldJadeDark
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldDark
import com.example.ui.theme.ImperialGoldLight
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.MidnightSurfaceHigh
import com.example.ui.theme.MidnightSurfaceLow
import com.example.ui.theme.MidnightSurfaceLowest
import com.example.ui.theme.OnSurfaceText
import com.example.ui.theme.OnSurfaceVariantText

private const val IMG_DI_DOM =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuD47mRyzzK9EPSxkHcqtX4YjzYGv6C2cnRQ0cqMt0LVYD8_d6mRGCoARCR9-QQIfUiNI5Y2iXzF-rUVxCDr96BXCfDf14-XS5vdQuevVkzXx9oaKxKR46_x-7X0xrbGWZJU1Rxl0pgyzJsTeznCXrvqS3z5xzN6DrPK-gNKOWOLaVhim8vWB3nr6Ktp4pl-J4T9UrQllXSVLvn8xvkn12qNndmgK-i0q2U9x3PDNAtc0mLYK92oS0az8w"

private const val IMG_NGHIEM_TUC =
    "https://lh3.googleusercontent.com/aida-public/AB6AXuCBxYZeV21ukurAat9JSjQDYHOtCdG_Y4GGGcZ1s-1XryFRU6V2DwX8KKr2hJ8WzfBHMN7_Ppo5VtWhJs_WfH8Q-9adSRZT2wOCOe8Qhm4VmXAe-DLcZeSK6RNgEbKjCDKIMDrL35SrAzZQ6R5I8dCoODt5RKx_8bdTivDbRz8VoW4sRhg-s5ZI_cok_3fFtTxmaiosFWt2PJF-UeuLN2amewFLMYpB8R5MecE5Rigie-3JZ4DpVN88hA"

@Composable
fun RitualStep1Screen(
    selectedStyle: String,
    humorLevel: Int,
    onStyleChange: (String) -> Unit,
    onHumorLevelChange: (Int) -> Unit,
    onNextStep: () -> Unit,
    onGoHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // PROGRESS TRACKER
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(ImperialGoldDark),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = ImperialGoldLight,
                        modifier = Modifier.size(14.dp)
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "KHỞI TÂM CẦU QUẺ",
                    color = ImperialGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(MidnightSurfaceLowest)
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Bước 1",
                    color = ImperialGold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = " / 3",
                    color = OnSurfaceVariantText,
                    fontSize = 11.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Progress Bar (33%)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(MidnightSurfaceLowest)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.33f)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(4.dp))
                    .background(
                        Brush.horizontalGradient(listOf(ImperialGold, ImperialGoldLight))
                    )
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Subtitle tag
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(MidnightSurfaceHigh.copy(alpha = 0.6f))
                .padding(horizontal = 10.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.LocalFireDepartment,
                contentDescription = null,
                tint = ImperialGold,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "LINH KHÍ KHAI NIÊN GIÁP THÌN",
                color = ImperialGold,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Hôm nay bạn muốn nhận lời chúc theo phong thái nào?",
            color = ImperialGold,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center,
            lineHeight = 24.sp
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Chạm thẻ bài định hình linh khí khởi lộc đầu xuân",
            color = OnSurfaceVariantText,
            fontSize = 12.sp,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(18.dp))

        // CARD 1: DÍ DỎM & PHÔNG BẠT
        val isDiDomSelected = selectedStyle == "di_dom"
        StyleCard(
            title = "DÍ DỎM & PHÔNG BẠT",
            tag = "TOP TREND • CỰC HOT",
            tagColor = CinnabarRed,
            tagIcon = Icons.Default.Whatshot,
            description = "Năng lượng hài hước bá đạo, bắt trend đỉnh chóp, cười rung lộc Tết!",
            quote = "“Tiền vô như thác lũ, thị phi tan thành mây”",
            imageUrl = IMG_DI_DOM,
            isSelected = isDiDomSelected,
            onClick = { onStyleChange("di_dom") },
            modifier = Modifier.testTag("style_card_di_dom")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // CARD 2: NGHIÊM TÚC & CHÂN THÀNH
        val isNghiemTucSelected = selectedStyle == "nghiem_tuc"
        StyleCard(
            title = "NGHIÊM TÚC & CHÂN THÀNH",
            tag = "TRANG TRỌNG • AN NHIÊN",
            tagColor = EmeraldJadeDark,
            tagIcon = Icons.Default.Spa,
            description = "Lời chúc sâu sắc ấm lòng, vạn sự bình an, trường thọ cát tường sum vầy.",
            quote = "“Tâm an vạn sự hưng, lộc biếc tựa hoa sen”",
            imageUrl = IMG_NGHIEM_TUC,
            isSelected = isNghiemTucSelected,
            onClick = { onStyleChange("nghiem_tuc") },
            modifier = Modifier.testTag("style_card_nghiem_tuc")
        )

        Spacer(modifier = Modifier.height(20.dp))

        // HUMOR & TONE GAUGE (1 to 5)
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MidnightSurfaceLow)
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = null,
                        tint = ImperialGold,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "ĐỘ HÀI HƯỚC & CHÂM BIẾM",
                        color = OnSurfaceText,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                val levelLabel = when (humorLevel) {
                    1 -> "Cấp 1/5: Nhẹ Nhàng"
                    2 -> "Cấp 2/5: Vừa Phải"
                    3 -> "Cấp 3/5: Vui Nhộn"
                    4 -> "Cấp 4/5: Bá Đạo"
                    else -> "Cấp 5/5: Cực Hạn"
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(ImperialGold)
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = levelLabel,
                        color = Color.Black,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // 5-level buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                val levels = listOf(
                    1 to ("🌱" to "Nhẹ"),
                    2 to ("😏" to "Vừa"),
                    3 to ("😂" to "Vui"),
                    4 to ("🔥" to "Bá đạo"),
                    5 to ("👑" to "Vô song")
                )

                levels.forEach { (lvl, pair) ->
                    val isLvlSelected = humorLevel == lvl
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 3.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(
                                if (isLvlSelected) ImperialGoldDark else MidnightSurfaceHigh
                            )
                            .clickable { onHumorLevelChange(lvl) }
                            .padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(text = pair.first, fontSize = 18.sp)
                        Text(
                            text = pair.second,
                            color = if (isLvlSelected) Color.White else OnSurfaceVariantText,
                            fontSize = 10.sp,
                            fontWeight = if (isLvlSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = ImperialGold,
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Phù trợ bách nghệ, cầu tài đắc tài",
                        color = OnSurfaceVariantText,
                        fontSize = 11.sp
                    )
                }
                Text(
                    text = "Khí Vận: +999",
                    color = ImperialGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // PRIMARY BUTTON: TIẾP TỤC BƯỚC 2 >
        Button(
            onClick = onNextStep,
            modifier = Modifier
                .testTag("btn_step1_next")
                .fillMaxWidth()
                .height(56.dp)
                .shadow(8.dp, RoundedCornerShape(28.dp)),
            shape = RoundedCornerShape(28.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(listOf(CinnabarRed, CinnabarDeep))
                    )
                    .border(1.dp, ImperialGoldLight, RoundedCornerShape(28.dp)),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Flare,
                        contentDescription = null,
                        tint = ImperialGoldLight,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "TIẾP TỤC BƯỚC 2 >",
                        color = ImperialGoldLight,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Return Home
        Row(
            modifier = Modifier
                .clickable { onGoHome() }
                .padding(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Home,
                contentDescription = null,
                tint = OnSurfaceVariantText,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Quay lại trang chủ",
                color = OnSurfaceVariantText,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun StyleCard(
    title: String,
    tag: String,
    tagColor: Color,
    tagIcon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    quote: String,
    imageUrl: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) MidnightSurfaceHigh else MidnightSurfaceLow)
            .border(
                width = if (isSelected) 2.dp else 1.dp,
                color = if (isSelected) ImperialGold else Color.Transparent,
                shape = RoundedCornerShape(16.dp)
            )
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Column {
            // Tag & Check indicator
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(tagColor)
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = tagIcon,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = tag,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) EmeraldJade else MidnightSurfaceLowest),
                    contentAlignment = Alignment.Center
                ) {
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "Đã chọn",
                            tint = Color(0xFF003828),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Body: Avatar + texts
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MidnightSurfaceLowest)
                ) {
                    AsyncImage(
                        model = imageUrl,
                        contentDescription = title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        color = if (isSelected) ImperialGold else OnSurfaceText,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = description,
                        color = OnSurfaceVariantText,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        maxLines = 2
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MidnightSurfaceLowest.copy(alpha = 0.8f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = quote,
                            color = ImperialGoldLight,
                            fontSize = 11.sp,
                            fontStyle = FontStyle.Italic,
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}
