package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = CinnabarRedLight,
    onPrimary = CinnabarRedDark,
    primaryContainer = CinnabarRed,
    onPrimaryContainer = Color(0xFFFFF0EF),
    secondary = ImperialGold,
    onSecondary = Color(0xFF422D00),
    secondaryContainer = ImperialGoldDark,
    onSecondaryContainer = Color(0xFF523900),
    tertiary = EmeraldJade,
    onTertiary = Color(0xFF003828),
    tertiaryContainer = EmeraldJadeDark,
    onTertiaryContainer = Color(0xFFCEFFE7),
    background = MidnightBackground,
    onBackground = OnSurfaceText,
    surface = MidnightSurface,
    onSurface = OnSurfaceText,
    surfaceVariant = MidnightSurfaceHighest,
    onSurfaceVariant = OnSurfaceVariantText,
    outline = OutlineBorder,
    outlineVariant = OutlineVariant,
    surfaceContainerLowest = MidnightSurfaceLowest,
    surfaceContainerLow = MidnightSurfaceLow,
    surfaceContainer = MidnightSurface,
    surfaceContainerHigh = MidnightSurfaceHigh,
    surfaceContainerHighest = MidnightSurfaceHighest
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
