package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.AutoFixHigh
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CrueltyFree
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LunchDining
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Redeem
import androidx.compose.material.icons.filled.SentimentVerySatisfied
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.ZodiacPetEntity
import com.example.ui.theme.CinnabarDeep
import com.example.ui.theme.CinnabarRed
import com.example.ui.theme.EmeraldJade
import com.example.ui.theme.EmeraldJadeDark
import com.example.ui.theme.ImperialGold
import com.example.ui.theme.ImperialGoldDark
import com.example.ui.theme.ImperialGoldLight
import com.example.ui.theme.MidnightBackground
import com.example.ui.theme.MidnightSurface
import com.example.ui.theme.MidnightSurfaceHigh
import com.example.ui.theme.MidnightSurfaceHighest
import com.example.ui.theme.MidnightSurfaceLow
import com.example.ui.theme.MidnightSurfaceLowest
import com.example.ui.theme.OnSurfaceText
import com.example.ui.theme.OnSurfaceVariantText
import kotlinx.coroutines.launch

private const val IMG_DRAGON_PET =
    "https://lh3.googleusercontent.com/aida/AEtjO1UUz8bQnKAAyeknYqTw8794fcbAlJnciBaDRSFzQZymxb5UVnxhE-dPj3eBS7jDUtewWx-U6LdOzEieWdld6hrmu21QzECRbuCmFlFPWZRYBxQoFLxQB65BdwR3b2T6NyUsSM-dbvpVGpvkF37dXioxGcHL6TLKcRbenXs3q92gmAspKdfFFmwoXazEaEmc-ttLqg-oVLXsk5xFiNPTt2I9hu-YQtYozNYaOlL4VTpHbCS9nlTRguiy1YN2"

@Composable
fun ZodiacPetScreen(
    activePet: ZodiacPetEntity?,
    allPets: List<ZodiacPetEntity>,
    onInteract: (type: String) -> Unit,
    onHarvest: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()
    val petScale = remember { Animatable(1f) }
    val coroutineScope = rememberCoroutineScope()

    val pet = activePet ?: ZodiacPetEntity(
        id = "thin",
        name = "Thần Long",
        title = "BẢO LONG KIM GIÁP",
        rarity = "Cực Phẩm",
        level = 5,
        cp = 12500,
        intimacy = 85,
        fullness = 90,
        happiness = 95,
        spiritualEnergy = 80,
        isCurrentActive = true,
        isUnlocked = true
    )

    fun tapPetInteraction(type: String) {
        coroutineScope.launch {
            petScale.animateTo(1.05f, tween(100))
            petScale.animateTo(1f, tween(100))
        }
        onInteract(type)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MidnightBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // TOP PET BANNER
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(18.dp))
                .background(MidnightSurfaceHigh)
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(MidnightSurfaceLowest),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stars,
                            contentDescription = null,
                            tint = ImperialGold,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = pet.title,
                                color = ImperialGold,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            )
                        }
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(ImperialGold.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = pet.rarity,
                                    color = ImperialGoldLight,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "Lv.${pet.level}",
                                color = CinnabarRed,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Bolt,
                                    contentDescription = null,
                                    tint = EmeraldJade,
                                    modifier = Modifier.size(13.dp)
                                )
                                Text(
                                    text = "CP ${String.format("%,d", pet.cp)}",
                                    color = EmeraldJade,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                IconButton(
                    onClick = { /* share pet */ },
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(MidnightSurfaceLow)
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Chia sẻ",
                        tint = OnSurfaceVariantText,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Intimacy Gauge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = null,
                        tint = CinnabarRed,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Độ Thân Thiết: ",
                        color = OnSurfaceVariantText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Text(
                    text = "${pet.intimacy}% / 100%",
                    color = CinnabarRed,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(MidnightSurfaceLowest)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(pet.intimacy / 100f)
                        .fillMaxSize()
                        .clip(RoundedCornerShape(4.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(CinnabarRed, ImperialGoldLight)
                            )
                        )
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 3D DRAGON STAGE WITH INTERACTIVE TOUCHPOINTS
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    Brush.verticalGradient(
                        listOf(MidnightSurfaceHigh.copy(alpha = 0.5f), MidnightSurfaceLowest)
                    )
                )
                .padding(8.dp),
            contentAlignment = Alignment.Center
        ) {
            // Dragon image
            AsyncImage(
                model = IMG_DRAGON_PET,
                contentDescription = "Bảo Long Kim Giáp 3D",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .scale(petScale.value)
            )

            // Touchpoint 1: Xoa Đầu (+5)
            Row(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = 36.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(MidnightSurfaceHighest.copy(alpha = 0.9f))
                    .border(1.dp, ImperialGold, RoundedCornerShape(20.dp))
                    .clickable { tapPetInteraction("head") }
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "👆", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Xoa đầu", color = ImperialGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(4.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(ImperialGold.copy(alpha = 0.25f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(text = "+5", color = ImperialGoldLight, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Touchpoint 2: Đào Tiên (+10)
            Row(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .offset(x = 12.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(MidnightSurfaceHighest.copy(alpha = 0.9f))
                    .border(1.dp, CinnabarRed, RoundedCornerShape(20.dp))
                    .clickable { tapPetInteraction("peach") }
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "🍑", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Đào tiên", color = CinnabarRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(4.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(CinnabarRed.copy(alpha = 0.25f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(text = "+10", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }

            // Touchpoint 3: Linh Tuyền (+15)
            Row(
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .offset(x = (-12).dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(MidnightSurfaceHighest.copy(alpha = 0.9f))
                    .border(1.dp, EmeraldJade, RoundedCornerShape(20.dp))
                    .clickable { tapPetInteraction("water") }
                    .padding(horizontal = 10.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "🌊", fontSize = 12.sp)
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "Linh tuyền", color = EmeraldJade, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.width(4.dp))
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(EmeraldJade.copy(alpha = 0.25f))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(text = "+15", color = EmeraldJade, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 3 INDICATORS: No Nê, Hạnh Phúc, Linh Lực
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            PetStatItem(
                icon = Icons.Default.LunchDining,
                label = "No Nê",
                value = pet.fullness,
                color = ImperialGold,
                modifier = Modifier.weight(1f)
            )
            PetStatItem(
                icon = Icons.Default.SentimentVerySatisfied,
                label = "H.Phúc",
                value = pet.happiness,
                color = CinnabarRed,
                modifier = Modifier.weight(1f)
            )
            PetStatItem(
                icon = Icons.Default.AutoFixHigh,
                label = "Linh Lực",
                value = pet.spiritualEnergy,
                color = EmeraldJade,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 2 ACTION BUTTONS: Thần Lương & Tương Tác 3D
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { tapPetInteraction("peach") },
                modifier = Modifier
                    .testTag("btn_feed_pet")
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldJadeDark)
            ) {
                Icon(
                    imageVector = Icons.Default.Grain,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Thần Lương",
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { tapPetInteraction("head") },
                modifier = Modifier
                    .testTag("btn_interact_pet")
                    .weight(1f)
                    .height(48.dp),
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MidnightSurfaceHigh)
            ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = ImperialGold,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Tương Tác 3D",
                    color = ImperialGold,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // HARVEST REWARD CARD
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(
                    Brush.horizontalGradient(
                        listOf(CinnabarRed.copy(alpha = 0.2f), MidnightSurfaceHigh)
                    )
                )
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(CinnabarRed),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Redeem,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "Nhận Lộc Linh Thú",
                        color = ImperialGold,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Thu hoạch +200 Xu • 1 Lì Xì Đỏ",
                        color = OnSurfaceVariantText,
                        fontSize = 11.sp
                    )
                }
            }

            Button(
                onClick = onHarvest,
                modifier = Modifier
                    .testTag("btn_harvest_pet")
                    .height(38.dp),
                shape = RoundedCornerShape(19.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ImperialGold)
            ) {
                Text(
                    text = "THU HOẠCH",
                    color = Color.Black,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // LINH THÚ VIÊN SECTION
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "LINH THÚ VIÊN",
                color = OnSurfaceText,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
            Text(
                text = "3 / 12 Đã Mở",
                color = OnSurfaceVariantText,
                fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        val petScroll = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(petScroll),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Pet 1: Thần Long
            ZodiacPetThumb(
                name = "Thần Long",
                subtitle = "Đang nuôi",
                icon = Icons.Default.CrueltyFree,
                isActive = true,
                color = ImperialGold
            )

            // Pet 2: Miêu Tài Lộc
            ZodiacPetThumb(
                name = "Miêu Tài Lộc",
                subtitle = "Lv.3",
                icon = Icons.Default.Pets,
                isActive = false,
                color = EmeraldJade
            )

            // Pet 3: Thỏ Ngọc
            ZodiacPetThumb(
                name = "Thỏ Ngọc",
                subtitle = "Lv.2",
                icon = Icons.Default.DarkMode,
                isActive = false,
                color = ImperialGoldLight
            )

            // Locked Slots
            for (i in 4..6) {
                ZodiacPetThumb(
                    name = "Chưa mở",
                    subtitle = "Khóa",
                    icon = Icons.Default.Lock,
                    isActive = false,
                    isLocked = true,
                    color = OnSurfaceVariantText
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
fun PetStatItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: Int,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MidnightSurfaceHigh)
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(13.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(text = label, color = OnSurfaceVariantText, fontSize = 10.sp)
            }
            Text(text = "$value%", color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(4.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(MidnightSurfaceLowest)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(value / 100f)
                    .fillMaxSize()
                    .clip(RoundedCornerShape(3.dp))
                    .background(color)
            )
        }
    }
}

@Composable
fun ZodiacPetThumb(
    name: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isActive: Boolean,
    color: Color,
    isLocked: Boolean = false
) {
    Column(
        modifier = Modifier
            .width(84.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(
                if (isActive) ImperialGold.copy(alpha = 0.15f)
                else MidnightSurfaceLow
            )
            .border(
                1.dp,
                if (isActive) ImperialGold else Color.Transparent,
                RoundedCornerShape(12.dp)
            )
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(MidnightSurfaceLowest),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = name,
                tint = if (isLocked) OnSurfaceVariantText.copy(alpha = 0.4f) else color,
                modifier = Modifier.size(24.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = name,
            color = if (isLocked) OnSurfaceVariantText.copy(alpha = 0.5f) else OnSurfaceText,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )

        Text(
            text = subtitle,
            color = if (isActive) ImperialGold else OnSurfaceVariantText,
            fontSize = 9.sp
        )
    }
}
