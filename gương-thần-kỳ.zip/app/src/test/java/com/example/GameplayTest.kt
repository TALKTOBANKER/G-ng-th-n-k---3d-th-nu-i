package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.repository.BlessingRepository
import com.example.ui.AppViewModel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class GameplayTest {

  @Test
  fun testGetRandomBlessing() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val repo = BlessingRepository(context)
    val blessing = repo.getRandomBlessing("tai_loc", "di_dom")
    println("BLESSING RESULT: ${blessing.title}")
    assertNotNull(blessing)
  }

  @Test
  fun testStrikeEggFlow() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val vm = AppViewModel(context as Application)
    assertEquals(0, vm.gameController.eggState.value.strikesDone)

    vm.strikeEgg()
    assertEquals(1, vm.gameController.eggState.value.strikesDone)

    vm.strikeEgg()
    assertEquals(2, vm.gameController.eggState.value.strikesDone)

    vm.strikeEgg()
    assertEquals(3, vm.gameController.eggState.value.strikesDone)
    assertTrue(vm.gameController.eggState.value.isBroken)
    println("Strike egg finished with 3 strikes and broken state")
  }

  @Test
  fun testTreasureChestFlow() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val vm = AppViewModel(context as Application)
    assertEquals(0, vm.gameController.chestState.value.chargePercent)

    vm.gameController.tapBaguaNode(0)
    assertEquals(20, vm.gameController.chestState.value.chargePercent)

    vm.gameController.touchChestMirror()
    assertEquals(40, vm.gameController.chestState.value.chargePercent)
    println("Treasure chest charge flow passed")
  }

  @Test
  fun testRedEnvelopeFlow() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val vm = AppViewModel(context as Application)

    // Test accelerometer reading
    vm.gameController.onAccelerometerReading(2.6f)
    assertTrue(vm.gameController.envelopeState.value.isDrawn || vm.gameController.envelopeState.value.isCoinRainActive)

    println("Red envelope shake flow passed")
  }
}
