package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Gương Thần Kỳ", appName)
  }

  @Test
  fun `verify blessing streaming works`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val stream = context.assets.open("blessings.json")
    val reader = android.util.JsonReader(java.io.InputStreamReader(stream, "UTF-8"))
    reader.beginArray()
    assertTrue(reader.hasNext())
    reader.close()
  }
}
